use std::collections::HashSet;

use glam::{Quat, Vec3};

use crate::ecs::{Entity, World};
use crate::engine::spatial_hash::SpatialHash2D;
use crate::game::components::{Parent, Transform};
use crate::render::terrain::Heightmap;

use super::components::{BodyType, Collider, PhysicsMaterial, RigidBody};

const SLEEP_LINEAR_THRESHOLD: f32 = 0.05;
const SLEEP_ANGULAR_THRESHOLD: f32 = 0.1;
const SLEEP_TIME_REQUIRED: f32 = 0.5;
const CONTACT_SLOP: f32 = 0.001;
const BAUMGARTE: f32 = 0.2;
const MAX_LINEAR_VELOCITY: f32 = 500.0;
const MAX_ANGULAR_VELOCITY: f32 = 50.0;
const VELOCITY_ITERATIONS: u32 = 4;

pub const MAX_DT: f32 = 0.05;

const CAPSULE_AABB_SAMPLES: u32 = 8;

pub struct PhysicsWorld {
    pub gravity: Vec3,
    pub enabled: bool,
    pub last_broad_pairs: usize,
    pub last_contacts: usize,
    warned_parent_bodies: HashSet<Entity>,
}

impl Default for PhysicsWorld {
    fn default() -> Self {
        Self {
            gravity: Vec3::new(0.0, -9.81, 0.0),
            enabled: true,
            last_broad_pairs: 0,
            last_contacts: 0,
            warned_parent_bodies: HashSet::new(),
        }
    }
}

#[derive(Clone, Copy)]
struct BodyState {
    entity: Entity,
    body_type: BodyType,
    inv_mass: f32,
    inv_inertia: f32,
    position: Vec3,
    velocity: Vec3,
    rotation: Quat,
    angular_velocity: Vec3,
    gravity_scale: f32,
    linear_damping: f32,
    angular_damping: f32,
    collider: Collider,
    material: PhysicsMaterial,
    scale: Vec3,
    sleeping: bool,
    sleep_timer: f32,
    parent_inv: glam::Mat4,
}

struct Contact {
    a: usize,
    b: usize,
    normal: Vec3,
    penetration: f32,
    point: Vec3,
}

impl PhysicsWorld {
    pub fn step(
        &mut self,
        world: &mut World,
        terrain: Option<&Heightmap>,
        dt: f32,
    ) {
        if !self.enabled || dt <= 0.0 {
            return;
        }
        let dt = dt.min(MAX_DT);

        let (mut states, skipped) = collect_states(world);
        self.warn_skipped_bodies(&skipped);

        if states.is_empty() {
            self.last_broad_pairs = 0;
            self.last_contacts = 0;
            return;
        }

        // 1. Интеграция.
        for s in states.iter_mut() {
            match s.body_type {
                BodyType::Dynamic if !s.sleeping => {
                    s.velocity += self.gravity * s.gravity_scale * dt;
                    let d = (1.0 - s.linear_damping * dt).max(0.0);
                    s.velocity *= d;
                    s.angular_velocity *= (1.0 - s.angular_damping * dt).max(0.0);

                    let vlen = s.velocity.length();
                    if vlen > MAX_LINEAR_VELOCITY {
                        s.velocity *= MAX_LINEAR_VELOCITY / vlen;
                    }
                    let wlen = s.angular_velocity.length();
                    if wlen > MAX_ANGULAR_VELOCITY {
                        s.angular_velocity *= MAX_ANGULAR_VELOCITY / wlen;
                    }

                    s.position += s.velocity * dt;
                    integrate_rotation(s, dt);
                }
                BodyType::Kinematic => {
                    s.position += s.velocity * dt;
                    integrate_rotation(s, dt);
                }
                _ => {}
            }
        }

        // === Terrain: вертикальная коллизия с heightmap ===
        if let Some(hm) = terrain {
            for s in states.iter_mut() {
                if s.body_type != BodyType::Dynamic {
                    continue;
                }
                let (mn, _mx) = global_aabb(s);
                let feet = Vec3::new(s.position.x, mn.y, s.position.z);
                if !hm.contains(feet.x, feet.z) {
                    continue;
                }
                let ground = hm.sample(feet.x, feet.z);
                if feet.y < ground {
                    let pen = ground - feet.y;
                    s.position.y += pen;
                    if s.velocity.y < 0.0 {
                        let restitution = s.material.restitution.min(0.5);
                        s.velocity.y = -s.velocity.y * restitution;
                    }
                    s.sleeping = false;
                    s.sleep_timer = 0.0;
                }
            }
        }

        // 2. Broad-phase (spatial hash).
        let pairs = broad_phase(&states);
        self.last_broad_pairs = pairs.len();

        // 3. Narrow-phase.
        let mut contacts: Vec<Contact> = Vec::new();
        for (i, j) in &pairs {
            if let Some(c) = collide(&states[*i], &states[*j], *i, *j) {
                contacts.push(c);
            }
        }
        self.last_contacts = contacts.len();

        // 4. Velocity solve.
        for _ in 0..VELOCITY_ITERATIONS {
            for c in &contacts {
                resolve_velocity(c, &mut states);
            }
        }

        // 4b. Support transfer (kinematic → dynamic на платформе).
        for c in &contacts {
            let a_kin = states[c.a].body_type == BodyType::Kinematic;
            let b_kin = states[c.b].body_type == BodyType::Kinematic;
            let a_dyn = states[c.a].body_type == BodyType::Dynamic;
            let b_dyn = states[c.b].body_type == BodyType::Dynamic;

            if a_kin && b_dyn && c.normal.y > 0.5 {
                states[c.b].velocity = states[c.a].velocity;
                states[c.b].angular_velocity = states[c.a].angular_velocity;
                states[c.b].sleeping = false;
                states[c.b].sleep_timer = 0.0;
            }
            if b_kin && a_dyn && c.normal.y < -0.5 {
                states[c.a].velocity = states[c.b].velocity;
                states[c.a].angular_velocity = states[c.b].angular_velocity;
                states[c.a].sleeping = false;
                states[c.a].sleep_timer = 0.0;
            }
        }

        // 5. Position correction.
        for c in &contacts {
            resolve_position(c, &mut states);
        }

        // 6. Sleep management.
        for s in states.iter_mut() {
            if s.body_type != BodyType::Dynamic {
                continue;
            }
            let lin = s.velocity.length();
            let ang = s.angular_velocity.length();
            if lin < SLEEP_LINEAR_THRESHOLD && ang < SLEEP_ANGULAR_THRESHOLD {
                s.sleep_timer += dt;
                if s.sleep_timer > SLEEP_TIME_REQUIRED {
                    s.sleeping = true;
                    s.velocity = Vec3::ZERO;
                    s.angular_velocity = Vec3::ZERO;
                }
            } else {
                s.sleep_timer = 0.0;
                s.sleeping = false;
            }
        }

        // 7. Записать обратно.
        write_back(world, &states);
    }

    fn warn_skipped_bodies(&mut self, skipped: &[Entity]) {
        let now: HashSet<Entity> = skipped.iter().copied().collect();
        for &e in &now {
            if !self.warned_parent_bodies.contains(&e) {
                log::warn!(
                    "Physics: entity #{} has RigidBody + Parent — not simulated.",
                    e
                );
            }
        }
        self.warned_parent_bodies = now;
    }
}

// ============================================================
// Rotation integration
// ============================================================

fn integrate_rotation(s: &mut BodyState, dt: f32) {
    if s.angular_velocity.length_squared() < 1e-10 {
        return;
    }
    let w = s.angular_velocity;
    let wq = Quat::from_xyzw(w.x, w.y, w.z, 0.0);
    let dq = wq * s.rotation;
    let new_q = Quat::from_xyzw(
        s.rotation.x + dq.x * 0.5 * dt,
        s.rotation.y + dq.y * 0.5 * dt,
        s.rotation.z + dq.z * 0.5 * dt,
        s.rotation.w + dq.w * 0.5 * dt,
    );
    s.rotation = new_q.normalize();
}

// ============================================================
// Inertia
// ============================================================

fn compute_inv_inertia(col: &Collider, mass: f32, scale: Vec3) -> f32 {
    if mass < 1e-6 {
        return 0.0;
    }
    let i = match col {
        Collider::Sphere { radius } => {
            let r = radius * scale.max_element();
            0.4 * mass * r * r
        }
        Collider::Aabb { half_extents } => {
            let h = *half_extents * scale;
            mass * (h.x * h.x + h.y * h.y + h.z * h.z) / 3.0
        }
        Collider::Capsule { radius, height } => {
            let r = radius * scale.max_element();
            let h = height * scale.y * 0.5;
            mass * (r * r * 0.5 + h * h / 3.0)
        }
    };
    if i > 1e-8 { 1.0 / i } else { 0.0 }
}

fn collect_states(world: &World) -> (Vec<BodyState>, Vec<Entity>) {
    let mut out = Vec::new();
    let skipped = Vec::new();
    for &e in world.entities() {
        let Some(rb) = world.get::<RigidBody>(e).copied() else {
            continue;
        };
        let Some(col) = world.get::<Collider>(e).copied() else {
            continue;
        };

        let Some(_t) = world.get::<Transform>(e) else {
            continue;
        };

        let (world_pos, world_rot, parent_inv) = if let Some(Parent(p)) = world.get::<Parent>(e).copied() {
            let pm = crate::game::world_matrix(world, p);
            let model = pm * _t.matrix();
            let (_, rot, pos) = model.to_scale_rotation_translation();
            (pos, rot, pm.inverse())
        } else {
            (_t.position, _t.rotation, glam::Mat4::IDENTITY)
        };

        let material = world.get::<PhysicsMaterial>(e).copied().unwrap_or_default();
        let mass = rb.mass.max(1e-4);
        let scale = _t.scale.abs();
        let inv_inertia = compute_inv_inertia(&col, mass, scale);

        out.push(BodyState {
            entity: e,
            body_type: rb.body_type,
            inv_mass: rb.inv_mass(),
            inv_inertia,
            position: world_pos,
            velocity: rb.velocity,
            rotation: world_rot.normalize(),
            angular_velocity: rb.angular_velocity,
            gravity_scale: rb.gravity_scale,
            linear_damping: rb.linear_damping,
            angular_damping: rb.angular_damping,
            collider: col,
            material,
            scale,
            sleeping: rb.sleeping,
            sleep_timer: rb.sleep_timer,
            parent_inv,
        });
    }
    (out, skipped)
}

fn write_back(world: &mut World, states: &[BodyState]) {
    for s in states {
        if let Some(t) = world.get_mut::<Transform>(s.entity) {
            if s.parent_inv != glam::Mat4::IDENTITY {
                let world_mat = glam::Mat4::from_scale_rotation_translation(s.scale, s.rotation, s.position);
                let local = s.parent_inv * world_mat;
                let (_, l_rot, l_pos) = local.to_scale_rotation_translation();
                t.position = l_pos;
                t.rotation = l_rot;
            } else {
                t.position = s.position;
                t.rotation = s.rotation;
            }
        }
        if let Some(rb) = world.get_mut::<RigidBody>(s.entity) {
            rb.velocity = s.velocity;
            rb.angular_velocity = s.angular_velocity;
            rb.sleeping = s.sleeping;
            rb.sleep_timer = s.sleep_timer;
            rb.force = Vec3::ZERO;
            rb.torque = Vec3::ZERO;
        }
    }
}

fn broad_phase(states: &[BodyState]) -> Vec<(usize, usize)> {
    let n = states.len();
    if n < 2 {
        return Vec::new();
    }

    let aabbs: Vec<(Vec3, Vec3)> = states.iter().map(global_aabb).collect();

    let mut hash = SpatialHash2D::new(4.0);
    for (i, (mn, mx)) in aabbs.iter().enumerate() {
        hash.insert_aabb(i as u32, *mn, *mx);
    }

    let mut pairs = Vec::new();
    let mut candidates: Vec<u32> = Vec::with_capacity(32);

    for i in 0..n {
        let si = &states[i];
        let (mn_i, mx_i) = aabbs[i];

        candidates.clear();
        hash.query_aabb(mn_i, mx_i, &mut candidates);

        for &j_u32 in &candidates {
            let j = j_u32 as usize;
            if j <= i {
                continue;
            }

            let sj = &states[j];

            if !can_move(si.body_type) && !can_move(sj.body_type) {
                continue;
            }
            if si.sleeping && sj.sleeping {
                continue;
            }

            if aabb_overlap(aabbs[i], aabbs[j]) {
                pairs.push((i, j));
            }
        }
    }

    pairs
}

fn can_move(bt: BodyType) -> bool {
    matches!(bt, BodyType::Dynamic | BodyType::Kinematic)
}

fn global_aabb(s: &BodyState) -> (Vec3, Vec3) {
    s.collider.world_aabb(s.position, s.rotation, s.scale)
}

fn aabb_overlap(a: (Vec3, Vec3), b: (Vec3, Vec3)) -> bool {
    a.0.x <= b.1.x && a.1.x >= b.0.x
        && a.0.y <= b.1.y && a.1.y >= b.0.y
        && a.0.z <= b.1.z && a.1.z >= b.0.z
}

// ============================================================
// Narrow-phase
// ============================================================

fn collide(a: &BodyState, b: &BodyState, ia: usize, ib: usize) -> Option<Contact> {
    match (a.collider, b.collider) {
        // --- Sphere vs Sphere ---
        (Collider::Sphere { radius: ra }, Collider::Sphere { radius: rb }) => {
            let r_a = ra * a.scale.max_element();
            let r_b = rb * b.scale.max_element();
            sphere_sphere(a.position, r_a, b.position, r_b, ia, ib)
        }
        // --- Sphere vs AABB ---
        (Collider::Sphere { radius }, Collider::Aabb { half_extents }) => {
            let r = radius * a.scale.max_element();
            let hb = half_extents * b.scale;
            sphere_aabb(a.position, r, b.position, hb, ia, ib)
        }
        (Collider::Aabb { half_extents }, Collider::Sphere { radius }) => {
            let ha = half_extents * a.scale;
            let r = radius * b.scale.max_element();
            let mut c = sphere_aabb(b.position, r, a.position, ha, ib, ia)?;
            c.normal = -c.normal;
            Some(Contact {
                a: ia,
                b: ib,
                normal: c.normal,
                penetration: c.penetration,
                point: c.point,
            })
        }
        // --- AABB vs AABB ---
        (Collider::Aabb { half_extents: ha }, Collider::Aabb { half_extents: hb }) => {
            let h_a = ha * a.scale;
            let h_b = hb * b.scale;
            aabb_aabb(a.position, h_a, b.position, h_b, ia, ib)
        }
        // === FIX #2: capsule narrow-phase ===
        // --- Capsule vs Capsule ---
        (
            Collider::Capsule { radius: ra, height: ha },
            Collider::Capsule { radius: rb, height: hb },
        ) => {
            let (a1, a2, r_a) = capsule_endpoints(a.position, a.rotation, a.scale, ra, ha);
            let (b1, b2, r_b) = capsule_endpoints(b.position, b.rotation, b.scale, rb, hb);
            capsule_capsule(a1, a2, r_a, b1, b2, r_b, ia, ib)
        }
        // --- Capsule vs Sphere ---
        (Collider::Capsule { radius, height }, Collider::Sphere { radius: r_b }) => {
            let (a1, a2, r_a) = capsule_endpoints(a.position, a.rotation, a.scale, radius, height);
            let sr = r_b * b.scale.max_element();
            capsule_sphere(a1, a2, r_a, b.position, sr, ia, ib)
        }
        (Collider::Sphere { radius }, Collider::Capsule { radius: r_b, height }) => {
            let sr = radius * a.scale.max_element();
            let (b1, b2, r_b_world) =
                capsule_endpoints(b.position, b.rotation, b.scale, r_b, height);
            let mut c = capsule_sphere(b1, b2, r_b_world, a.position, sr, ib, ia)?;
            c.normal = -c.normal;
            Some(Contact {
                a: ia,
                b: ib,
                normal: c.normal,
                penetration: c.penetration,
                point: c.point,
            })
        }
        // --- Capsule vs AABB ---
        (Collider::Capsule { radius, height }, Collider::Aabb { half_extents }) => {
            let (a1, a2, r_a) = capsule_endpoints(a.position, a.rotation, a.scale, radius, height);
            let hb = half_extents * b.scale;
            capsule_aabb(a1, a2, r_a, b.position, hb, ia, ib)
        }
        (Collider::Aabb { half_extents }, Collider::Capsule { radius, height }) => {
            let ha = half_extents * a.scale;
            let (b1, b2, r_b) = capsule_endpoints(b.position, b.rotation, b.scale, radius, height);
            let mut c = capsule_aabb(b1, b2, r_b, a.position, ha, ib, ia)?;
            c.normal = -c.normal;
            Some(Contact {
                a: ia,
                b: ib,
                normal: c.normal,
                penetration: c.penetration,
                point: c.point,
            })
        }
    }
}

#[allow(dead_code)]
fn state_as_aabb(s: &BodyState) -> (Vec3, Vec3) {
    let (mn, mx) = global_aabb(s);
    (s.position, (mx - mn) * 0.5)
}

fn closest_point_on_aabb(p: Vec3, center: Vec3, half: Vec3) -> Vec3 {
    p.clamp(center - half, center + half)
}

#[inline]
fn capsule_endpoints(
    pos: Vec3,
    rotation: Quat,
    scale: Vec3,
    radius: f32,
    height: f32,
) -> (Vec3, Vec3, f32) {
    let r = radius * scale.max_element();
    let hy = height * scale.y.abs() * 0.5;
    let up = rotation * Vec3::new(0.0, hy, 0.0);
    (pos - up, pos + up, r)
}

fn closest_segment_segment(p1: Vec3, q1: Vec3, p2: Vec3, q2: Vec3) -> (Vec3, Vec3) {
    let d1 = q1 - p1;
    let d2 = q2 - p2;
    let r = p1 - p2;
    let a = d1.dot(d1);
    let e = d2.dot(d2);
    let f = d2.dot(r);

    let (mut s, mut t);
    if a <= 1e-8 && e <= 1e-8 {
        return (p1, p2);
    }
    if a <= 1e-8 {
        s = 0.0;
        t = (f / e).clamp(0.0, 1.0);
    } else {
        let c = d1.dot(r);
        if e <= 1e-8 {
            t = 0.0;
            s = (-c / a).clamp(0.0, 1.0);
        } else {
            let b = d1.dot(d2);
            let denom = a * e - b * b;
            s = if denom.abs() > 1e-8 {
                ((b * f - c * e) / denom).clamp(0.0, 1.0)
            } else {
                0.0
            };
            t = (b * s + f) / e;
            if t < 0.0 {
                t = 0.0;
                s = (-c / a).clamp(0.0, 1.0);
            } else if t > 1.0 {
                t = 1.0;
                s = ((b - c) / a).clamp(0.0, 1.0);
            }
        }
    }
    (p1 + d1 * s, p2 + d2 * t)
}

fn closest_on_segment(p: Vec3, a: Vec3, b: Vec3) -> Vec3 {
    let ab = b - a;
    let t = (p - a).dot(ab) / ab.length_squared().max(1e-12);
    a + ab * t.clamp(0.0, 1.0)
}

fn capsule_capsule(
    a1: Vec3,
    a2: Vec3,
    ra: f32,
    b1: Vec3,
    b2: Vec3,
    rb: f32,
    ia: usize,
    ib: usize,
) -> Option<Contact> {
    let (ca, cb) = closest_segment_segment(a1, a2, b1, b2);
    let d = cb - ca;
    let dist = d.length();
    let r_sum = ra + rb;
    if dist >= r_sum {
        return None;
    }
    let normal = if dist > 1e-6 { d / dist } else { Vec3::Y };
    let pen = r_sum - dist;
    let point = ca + normal * (ra - pen * 0.5);
    Some(Contact {
        a: ia,
        b: ib,
        normal,
        penetration: pen,
        point,
    })
}

fn capsule_sphere(
    c1: Vec3,
    c2: Vec3,
    cr: f32,
    center: Vec3,
    sr: f32,
    ia: usize,
    ib: usize,
) -> Option<Contact> {
    let closest = closest_on_segment(center, c1, c2);
    sphere_sphere(closest, cr, center, sr, ia, ib)
}

fn capsule_aabb(
    c1: Vec3,
    c2: Vec3,
    cr: f32,
    center: Vec3,
    half: Vec3,
    ia: usize,
    ib: usize,
) -> Option<Contact> {
    // Sampling вдоль оси капсулы. Для типичных FPS (игрок-капсула на
    // коробке) 8 сэмплов дают точность < 1 см на краю.
    // Возвращаем контакт с **максимальной** пенетрацией — это
    // соответствует «глубокой» точке сближения.
    let mut best: Option<Contact> = None;
    let n = CAPSULE_AABB_SAMPLES;
    for i in 0..=n {
        let t = i as f32 / n as f32;
        let p = c1.lerp(c2, t);
        if let Some(c) = sphere_aabb(p, cr, center, half, ia, ib)
            && best.as_ref().is_none_or(|b| c.penetration > b.penetration)
        {
            best = Some(c);
        }
    }
    best
}

// ============================================================
// Primitive narrow-phase
// ============================================================

fn sphere_sphere(
    pa: Vec3,
    ra: f32,
    pb: Vec3,
    rb: f32,
    ia: usize,
    ib: usize,
) -> Option<Contact> {
    let d = pb - pa;
    let dist_sq = d.length_squared();
    let r_sum = ra + rb;
    if dist_sq >= r_sum * r_sum {
        return None;
    }
    let dist = dist_sq.sqrt();
    let normal = if dist > 1e-6 { d / dist } else { Vec3::Y };
    let pen = r_sum - dist;
    let point = pa + normal * (ra - pen * 0.5);
    Some(Contact {
        a: ia,
        b: ib,
        normal,
        penetration: pen,
        point,
    })
}

fn sphere_aabb(
    pc: Vec3,
    r: f32,
    center: Vec3,
    half: Vec3,
    ia: usize,
    ib: usize,
) -> Option<Contact> {
    let closest = closest_point_on_aabb(pc, center, half);
    let d = pc - closest;
    let dist_sq = d.length_squared();
    if dist_sq >= r * r {
        return None;
    }
    let dist = dist_sq.sqrt();
    let normal = if dist > 1e-6 {
        -(d / dist)
    } else {
        let diff = pc - center;
        let dx = half.x - diff.x.abs();
        let dy = half.y - diff.y.abs();
        let dz = half.z - diff.z.abs();
        if dx < dy && dx < dz {
            Vec3::new(diff.x.signum(), 0.0, 0.0)
        } else if dy < dz {
            Vec3::new(0.0, diff.y.signum(), 0.0)
        } else {
            Vec3::new(0.0, 0.0, diff.z.signum())
        }
    };
    let pen = r - dist;
    let point = closest;
    Some(Contact {
        a: ia,
        b: ib,
        normal,
        penetration: pen,
        point,
    })
}

fn aabb_aabb(
    pa: Vec3,
    ha: Vec3,
    pb: Vec3,
    hb: Vec3,
    ia: usize,
    ib: usize,
) -> Option<Contact> {
    let d = pb - pa;
    let ox = ha.x + hb.x - d.x.abs();
    let oy = ha.y + hb.y - d.y.abs();
    let oz = ha.z + hb.z - d.z.abs();
    if ox <= 0.0 || oy <= 0.0 || oz <= 0.0 {
        return None;
    }
    let (pen, normal) = if ox <= oy && ox <= oz {
        (ox, Vec3::new(d.x.signum(), 0.0, 0.0))
    } else if oy <= oz {
        (oy, Vec3::new(0.0, d.y.signum(), 0.0))
    } else {
        (oz, Vec3::new(0.0, 0.0, d.z.signum()))
    };
    let point_a = closest_point_on_aabb(pb, pa, ha);
    let point_b = closest_point_on_aabb(pa, pb, hb);
    let point = (point_a + point_b) * 0.5;
    Some(Contact {
        a: ia,
        b: ib,
        normal,
        penetration: pen,
        point,
    })
}

// ============================================================
// Resolve (linear + angular)
// ============================================================

fn resolve_velocity(c: &Contact, states: &mut [BodyState]) {
    let inv_m_a = states[c.a].inv_mass;
    let inv_m_b = states[c.b].inv_mass;
    let inv_i_a = states[c.a].inv_inertia;
    let inv_i_b = states[c.b].inv_inertia;
    let inv_sum = inv_m_a + inv_m_b;
    if inv_sum <= 0.0 && inv_i_a <= 0.0 && inv_i_b <= 0.0 {
        return;
    }

    let ra = c.point - states[c.a].position;
    let rb = c.point - states[c.b].position;

    let va = states[c.a].velocity + states[c.a].angular_velocity.cross(ra);
    let vb = states[c.b].velocity + states[c.b].angular_velocity.cross(rb);
    let v_rel = vb - va;
    let v_n = v_rel.dot(c.normal);
    if v_n > 0.0 {
        return;
    }

    let ra_xn = ra.cross(c.normal);
    let rb_xn = rb.cross(c.normal);
    let ang_a = inv_i_a * ra_xn.length_squared();
    let ang_b = inv_i_b * rb_xn.length_squared();
    let k = inv_sum + ang_a + ang_b;
    if k <= 1e-8 {
        return;
    }

    let e = states[c.a]
        .material
        .restitution
        .min(states[c.b].material.restitution);
    let j = -(1.0 + e) * v_n / k;
    let impulse = c.normal * j;

    states[c.a].velocity -= impulse * inv_m_a;
    states[c.b].velocity += impulse * inv_m_b;
    states[c.a].angular_velocity -= ra.cross(impulse) * inv_i_a;
    states[c.b].angular_velocity += rb.cross(impulse) * inv_i_b;

    let va = states[c.a].velocity + states[c.a].angular_velocity.cross(ra);
    let vb = states[c.b].velocity + states[c.b].angular_velocity.cross(rb);
    let v_rel = vb - va;
    let v_n_after = v_rel.dot(c.normal);
    let v_t = v_rel - c.normal * v_n_after;
    let v_t_len = v_t.length();
    if v_t_len > 1e-6 {
        let tangent = v_t / v_t_len;
        let ra_xt = ra.cross(tangent);
        let rb_xt = rb.cross(tangent);
        let kt = inv_sum + inv_i_a * ra_xt.length_squared() + inv_i_b * rb_xt.length_squared();
        if kt > 1e-8 {
            let jt_unclamped = -v_t.dot(tangent) / kt;
            let mu = (states[c.a].material.friction + states[c.b].material.friction) * 0.5;
            let max_friction = mu * j.abs();
            let jt = jt_unclamped.clamp(-max_friction, max_friction);
            let tan_impulse = tangent * jt;
            states[c.a].velocity -= tan_impulse * inv_m_a;
            states[c.b].velocity += tan_impulse * inv_m_b;
            states[c.a].angular_velocity -= ra.cross(tan_impulse) * inv_i_a;
            states[c.b].angular_velocity += rb.cross(tan_impulse) * inv_i_b;
        }
    }

    states[c.a].sleeping = false;
    states[c.a].sleep_timer = 0.0;
    states[c.b].sleeping = false;
    states[c.b].sleep_timer = 0.0;
}

fn resolve_position(c: &Contact, states: &mut [BodyState]) {
    let inv_m_a = states[c.a].inv_mass;
    let inv_m_b = states[c.b].inv_mass;
    let inv_sum = inv_m_a + inv_m_b;
    if inv_sum <= 0.0 {
        return;
    }

    let pen = (c.penetration - CONTACT_SLOP).max(0.0);
    if pen < 1e-6 {
        return;
    }

    let correction = c.normal * (BAUMGARTE * pen / inv_sum);
    states[c.a].position -= correction * inv_m_a;
    states[c.b].position += correction * inv_m_b;
}

// ============================================================
// Тесты (FIX #2)
// ============================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn closest_segment_segment_parallel() {
        let (a, b) = closest_segment_segment(
            Vec3::new(0.0, 0.0, 0.0),
            Vec3::new(1.0, 0.0, 0.0),
            Vec3::new(0.0, 1.0, 0.0),
            Vec3::new(1.0, 1.0, 0.0),
        );
        assert!((a.y).abs() < 1e-4);
        assert!((b.y - 1.0).abs() < 1e-4);
    }

    #[test]
    fn closest_segment_segment_crossing() {
        let (a, b) = closest_segment_segment(
            Vec3::new(-1.0, 0.0, 0.0),
            Vec3::new(1.0, 0.0, 0.0),
            Vec3::new(0.0, -1.0, 0.0),
            Vec3::new(0.0, 1.0, 0.0),
        );
        assert!((a - Vec3::ZERO).length() < 1e-4);
        assert!((b - Vec3::ZERO).length() < 1e-4);
    }

    #[test]
    fn capsule_capsule_head_on() {
        let c = capsule_capsule(
            Vec3::new(0.0, -0.5, 0.0),
            Vec3::new(0.0, 0.5, 0.0),
            0.5,
            Vec3::new(0.0, 1.3, 0.0),
            Vec3::new(0.0, 2.3, 0.0),
            0.5,
            0,
            1,
        );
        let c = c.expect("капсулы должны пересекаться");
        assert!((c.penetration - 0.2).abs() < 0.05, "pen = {}", c.penetration);
        assert!(c.normal.y > 0.9, "normal = {:?}", c.normal);
    }

    #[test]
    fn capsule_capsule_apart() {
        let c = capsule_capsule(
            Vec3::new(0.0, 0.0, 0.0),
            Vec3::new(0.0, 1.0, 0.0),
            0.3,
            Vec3::new(5.0, 0.0, 0.0),
            Vec3::new(5.0, 1.0, 0.0),
            0.3,
            0,
            1,
        );
        assert!(c.is_none());
    }

    #[test]
    fn capsule_sphere_hit() {
        let c = capsule_sphere(
            Vec3::new(0.0, 0.0, 0.0),
            Vec3::new(0.0, 1.0, 0.0),
            0.5,
            Vec3::new(0.7, 0.5, 0.0),
            0.3,
            0,
            1,
        );
        assert!(c.is_some());
        let c = c.unwrap();
        assert!((c.penetration - 0.1).abs() < 0.01);
    }

    #[test]
    fn capsule_aabb_stand_on_top() {
        let c = capsule_aabb(
            Vec3::new(0.0, 0.6, 0.0),
            Vec3::new(0.0, 1.6, 0.0),
            0.4,
            Vec3::new(0.0, 0.0, 0.0),
            Vec3::splat(0.5),
            0,
            1,
        );
        let c = c.expect("капсула стоит на коробке");
        assert!(c.normal.y < -0.9, "normal = {:?}", c.normal);
        assert!(
            (c.penetration - 0.3).abs() < 0.05,
            "pen = {}",
            c.penetration
        );
    }

    #[test]
    fn collide_dispatches_capsule() {
        let cap = BodyState {
            entity: Entity::from_raw(0, 0),
            body_type: BodyType::Dynamic,
            inv_mass: 1.0,
            inv_inertia: 1.0,
            position: Vec3::new(0.0, 1.0, 0.0),
            velocity: Vec3::ZERO,
            rotation: Quat::IDENTITY,
            angular_velocity: Vec3::ZERO,
            gravity_scale: 1.0,
            linear_damping: 0.0,
            angular_damping: 0.0,
            collider: Collider::Capsule {
                radius: 0.5,
                height: 1.0,
            },
            material: PhysicsMaterial::default(),
            scale: Vec3::ONE,
            sleeping: false,
            sleep_timer: 0.0,
            parent_inv: glam::Mat4::IDENTITY,            
        };
        let box_ = BodyState {
            entity: Entity::from_raw(1, 0),
            body_type: BodyType::Static,
            inv_mass: 0.0,
            inv_inertia: 0.0,
            position: Vec3::ZERO,
            velocity: Vec3::ZERO,
            rotation: Quat::IDENTITY,
            angular_velocity: Vec3::ZERO,
            gravity_scale: 0.0,
            linear_damping: 0.0,
            angular_damping: 0.0,
            collider: Collider::Aabb {
                half_extents: Vec3::splat(0.5),
            },
            material: PhysicsMaterial::default(),
            scale: Vec3::ONE,
            sleeping: false,
            sleep_timer: 0.0,
            parent_inv: glam::Mat4::IDENTITY,            
        };        
        let c = collide(&cap, &box_, 0, 1);
        assert!(c.is_some(), "capsule-vs-aabb must produce contact");
    }
}