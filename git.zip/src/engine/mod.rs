pub mod ai_system;
pub mod app;
pub mod audio;
pub mod collision;
pub mod collision_cache;
pub mod crash;
pub mod input;
pub mod input_actions;
pub mod input_keys;
pub mod logger; // <-- НОВЫЙ МОДУЛЬ
pub mod particles;
pub mod spatial_hash;
pub mod time;

pub use ai_system::{AiSystem, AiTuning};
pub use app::{run, Game, ShotFired, WorldLoadRequest};
pub use audio::AudioSystem;
pub use collision::PlayerCapsule;
pub use collision_cache::{ColliderCache, ColliderEntry};
pub use input::Input;
pub use input_actions::{Binding, InputMap, InputMapFile, MouseBtn};
pub use input_keys::Key;
pub use particles::{BurstParams, Particle};
pub use spatial_hash::SpatialHash2D;
pub use time::Time;