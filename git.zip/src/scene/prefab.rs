use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};

use glam::Vec3;

use crate::ecs::{Entity, World};
use crate::game::components::Parent;
use crate::scene::serialize::{snapshot_entity, spawn_snapshot, EntitySnapshot};

#[derive(Serialize, Deserialize, Default, Clone)]
pub struct PrefabFile {
    #[serde(default)]
    pub name: Option<String>,
    pub entities: Vec<EntitySnapshot>,
}

pub fn prefab_from_selection(
    world: &World,
    selected: &[Entity],
    name: Option<String>,
) -> PrefabFile {
    let mut sorted: Vec<Entity> = selected.to_vec();
    sorted.sort();
    sorted.dedup();

    let mut entities: Vec<EntitySnapshot> = Vec::with_capacity(sorted.len());
    let mut id_to_idx: HashMap<Entity, Entity> = HashMap::new();

    for &e in &sorted {
        if let Some(snap) = snapshot_entity(world, e) {
            let idx = entities.len() as u32;
            id_to_idx.insert(e, Entity::from_raw(idx, 0));
            entities.push(snap);
        }
    }

    for snap in &mut entities {
        if let Some(p) = snap.parent {
            snap.parent = id_to_idx.get(&p).copied();
        }
    }

    PrefabFile { name, entities }
}

pub fn save_prefab_to_file(prefab: &PrefabFile, path: impl AsRef<Path>) -> Result<()> {
    let text = ron::ser::to_string_pretty(prefab, ron::ser::PrettyConfig::default())
        .context("serialize prefab")?;
    let path = path.as_ref();
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).ok();
    }
    std::fs::write(path, text)
        .with_context(|| format!("write prefab {}", path.display()))?;
    Ok(())
}

pub fn load_prefab_from_file(path: impl AsRef<Path>) -> Result<PrefabFile> {
    let text = std::fs::read_to_string(path.as_ref())
        .with_context(|| format!("read prefab {}", path.as_ref().display()))?;
    ron::from_str(&text).context("parse RON prefab")
}

pub fn instantiate_prefab(
    world: &mut World,
    prefab: &PrefabFile,
    offset: Vec3,
) -> Vec<Entity> {
    let n = prefab.entities.len() as u32;

    let is_root = |parent: Option<Entity>| -> bool {
        match parent {
            None => true,
            Some(p) => p.index >= n,
        }
    };

    let mut idx_to_entity: HashMap<Entity, Entity> = HashMap::new();
    let mut new_entities: Vec<Entity> = Vec::with_capacity(prefab.entities.len());

    for (idx, snap) in prefab.entities.iter().enumerate() {
        let mut s = snap.clone();
        s.parent = None;

        if is_root(snap.parent)
            && let Some(ref mut t) = s.transform
        {
            t.position[0] += offset.x;
            t.position[1] += offset.y;
            t.position[2] += offset.z;
        }

        let e = spawn_snapshot(world, s);
        idx_to_entity.insert(Entity::from_raw(idx as u32, 0), e);
        new_entities.push(e);
    }

    for (idx, snap) in prefab.entities.iter().enumerate() {
        let Some(old_parent) = snap.parent else {
            continue;
        };
        if old_parent.index >= n {
            continue;
        }
        let (Some(&new_parent), Some(&new_self)) = (
            idx_to_entity.get(&old_parent),
            idx_to_entity.get(&Entity::from_raw(idx as u32, 0)),
        ) else {
            continue;
        };
        world.insert(new_self, Parent(new_parent));
    }

    new_entities
}

pub fn list_prefabs(dir: impl AsRef<Path>) -> Vec<PathBuf> {
    let mut out = Vec::new();
    let Ok(entries) = std::fs::read_dir(dir.as_ref()) else {
        return out;
    };
    for entry in entries.flatten() {
        let p = entry.path();
        if !p.is_file() {
            continue;
        }
        let Some(name) = p.file_name().and_then(|s| s.to_str()) else {
            continue;
        };
        if name.ends_with(".prefab.ron") {
            out.push(p);
        }
    }
    out.sort();
    out
}

pub fn prefab_display_name(path: &Path) -> String {
    path.file_name()
        .and_then(|s| s.to_str())
        .map(|s| s.trim_end_matches(".prefab.ron").to_string())
        .unwrap_or_else(|| "?".to_string())
}