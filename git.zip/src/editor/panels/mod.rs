pub mod audio;
pub mod bookmarks;
pub mod command_palette;
pub mod console;
pub mod content;
pub mod details;
pub mod dialog_editor;
pub mod inspector_audio;
pub mod left_panel;
pub mod outliner;
pub mod overlays;
pub mod palette;
pub mod renderer;
pub mod right_panel;
pub mod scene_validation;
pub mod scripts;
pub mod settings_panel;
pub mod stats;
pub mod terrain;
pub mod top_bar;
pub mod viewport_toolbar;
pub mod workspace_tabs;

use crate::assets::AssetDatabase;
use crate::ecs::World;
use crate::editor::{EditorAction, EditorState};
use crate::game::audio::AudioBus;
use crate::render::Material;
use crate::scripting::ScriptSystem;

pub struct Stats {
    pub fps: f32,
    pub frame_time_max_ms: f32,
    pub hitches: u64,
    pub entities: usize,
    pub draws: usize,
    pub instances: usize,
    pub dir_lights: usize,
    pub point_lights: usize,
    pub lod_counts: [usize; 4],
    pub lod_triangles: [usize; 4],
    pub sel_entities: usize,
    pub sel_triangles: usize,
    pub sel_vertices: usize,
    pub extra_lines: Vec<(String, String)>,

    pub update_ms: f32,
    pub physics_ms: f32,
    pub ai_ms: f32,
    pub scripts_ms: f32,
    pub collect_ms: f32,
    pub render_ms: f32,
    pub egui_ms: f32,
    pub total_cpu_ms: f32,
}

pub struct UiAssets<'a> {
    pub mesh_names: &'a [String],
    pub material_names: &'a [String],
    pub texture_list: &'a [(String, u32, u32, bool)],
    pub selected_material: Option<(String, Material)>,
}

#[derive(Default)]
pub struct AudioSnapshot {
    pub bus_volumes: Vec<(AudioBus, f32)>,
    pub sound_names: Vec<String>,
    pub active_count: usize,
    pub available: bool,
    pub selected_source_entity: Option<crate::ecs::Entity>,
}

#[allow(clippy::too_many_arguments)]
pub fn draw_all(
    ui: &mut egui::Ui,
    state: &mut EditorState,
    world: &mut World,
    postfx: &mut crate::render::PostFx,
    stats: &Stats,
    assets: &UiAssets<'_>,
    audio: &AudioSnapshot,
    asset_db: &mut AssetDatabase,
    scripts: &ScriptSystem,
    has_pause_menu: bool,
) -> (Option<EditorAction>, egui::Rect) {
    let mut action: Option<EditorAction> = None;
    let in_play = state.play.active;

    // 1. Верхнее меню — всегда.
    top_bar::draw_menu(ui, state, &mut action);

    // 2. Тулбар — всегда.
    top_bar::draw_toolbar(ui, state, stats, &mut action);

    // 3. Панели редактора — только вне Play.
    if !in_play {
        let bottom_height = 260.0;
        egui::Panel::bottom("bottom_panel")
            .resizable(true)
            .default_size(bottom_height)
            .show(ui, |ui| {
                ui.horizontal(|ui| {
                    let half_width = ui.available_width() * 0.6;
                    ui.allocate_ui_with_layout(
                        egui::vec2(half_width, ui.available_height()),
                        egui::Layout::top_down(egui::Align::Min),
                        |ui| {
                            content::draw_project_panel(ui, state, asset_db);
                        },
                    );
                    ui.separator();
                    ui.allocate_ui_with_layout(
                        egui::vec2(ui.available_width(), ui.available_height()),
                        egui::Layout::top_down(egui::Align::Min),
                        |ui| {
                            console::draw(ui, state);
                        },
                    );
                });
            });

        left_panel::draw(ui, state, world, assets, stats, &mut action);
        right_panel::draw(ui, state, world, assets, postfx, &mut action);
    }

    // 4. Центральная панель (Viewport) — всегда.
    let central = egui::CentralPanel::default()
        .frame(egui::Frame::NONE)
        .show(ui, |ui| {
            if !in_play {
                viewport_toolbar::draw(ui, state);
            }
        });
    let viewport_rect = central.response.rect;

    // 5. Оверлеи редактора — только вне Play.
    if !in_play {
        overlays::draw_box_select_overlay(ui.ctx(), state);
        overlays::draw_context_menu(ui.ctx(), state, world, &mut action);

        if state.command_palette_open {
            command_palette::draw(ui.ctx(), state, &mut action);
        }

        bookmarks::draw(ui.ctx(), state, &mut action);
        audio::draw(ui.ctx(), state, audio, &mut action);

        inspector_audio::draw_window(ui.ctx(), state, world, audio, &mut action);

        let show_content = &mut state.layout.show_content_browser;
        let thumbnails = &mut state.thumbnails;
        content::draw_window(ui.ctx(), show_content, asset_db, thumbnails);

        let mut show_scripts = state.layout.show_script_panel;
        scripts::draw_window(
            ui.ctx(),
            &mut show_scripts,
            state,
            &*world,
            scripts,
            &mut action,
        );
        state.layout.show_script_panel = show_scripts;

        settings_panel::draw_window(ui.ctx(), state, stats);
        scene_validation::draw_window(ui.ctx(), state, world, &mut action);
    }

    // 6. Pause-overlay редактора — только если у игры нет своего.
    if in_play && state.play.paused && !has_pause_menu {
        overlays::draw_pause_overlay(ui.ctx(), state, &mut action);
    }

    // 7. Hint.
    if let Some((text, ttl)) = &state.hint {
        let alpha = ttl.clamp(0.0, 1.0);
        egui::Area::new(egui::Id::unique("editor_hint"))
            .anchor(egui::Align2::CENTER_TOP, egui::vec2(0.0, 80.0))
            .interactable(false)
            .show(ui.ctx(), |ui| {
                egui::Frame::popup(ui.style())
                    .fill(egui::Color32::from_rgba_unmultiplied(
                        20,
                        20,
                        30,
                        (220.0 * alpha) as u8,
                    ))
                    .inner_margin(egui::Margin::symmetric(12, 6))
                    .show(ui, |ui| {
                        ui.label(egui::RichText::new(text).color(
                            egui::Color32::from_rgba_unmultiplied(
                                255,
                                230,
                                180,
                                (255.0 * alpha) as u8,
                            ),
                        ));
                    });
            });
    }

    (action, viewport_rect)
}