//! Настройки редактора. Сохраняются в `editor.ron` при выходе
//! и загружаются при старте.

use std::collections::{BTreeMap, HashMap};
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::render::PostFx;

use super::camera_bookmarks::CameraBookmarks;
use super::hotkeys::HotkeyMap;
use super::layout::{LayoutState, Workspace};
use super::theme::Theme;

const MAX_RECENT: usize = 8;

/// Текущая версия формата `editor.ron`.
fn current_format() -> u32 { 1 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EditorSettings {
    /// Версия формата. При добавлении/переименовании полей — инкрементировать
    /// и добавить миграцию в `migrate()`.
    #[serde(default = "current_format")]
    pub format: u32,

    // === Панели (legacy, дублирует активный workspace) ===
    pub show_renderer_panel: bool,
    pub show_stats_panel: bool,
    pub show_hierarchy_panel: bool,
    pub show_inspector_panel: bool,
    #[serde(default)]
    pub show_audio_panel: bool,

    #[serde(default)]
    pub show_navmesh: bool,

    pub left_panel_width: f32,
    pub right_panel_width: f32,

    // === Workspace system ===
    #[serde(default)]
    pub active_workspace: Workspace,
    #[serde(default)]
    pub workspace_layouts: BTreeMap<Workspace, LayoutState>,

    // === Theme ===
    #[serde(default)]
    pub theme: Theme,

    // === Hotkeys ===
    #[serde(default)]
    pub hotkeys: HotkeyMap,

    // === Пути ===
    pub save_path: String,
    pub prefabs_dir: String,
    pub fbx_export_path: String,

    // === Fly ===
    pub fly_speed: f32,
    pub fly_sensitivity: f32,

    // === Gizmo / палитра ===
    pub gizmo_snap: bool,
    pub palette_keep_active: bool,
    pub palette_snap_to_grid: bool,
    pub palette_grid_step: f32,

    // === Recent ===
    pub recent_scenes: Vec<String>,

    #[serde(default)]
    pub camera_bookmarks: CameraBookmarks,

    #[serde(default)]
    pub postfx: PostFx,

    #[serde(default)]
    pub audio_bus_volumes: HashMap<String, f32>,
}

impl Default for EditorSettings {
    fn default() -> Self {
        Self {
            format: current_format(),
            show_renderer_panel: true,
            show_stats_panel: true,
            show_hierarchy_panel: true,
            show_inspector_panel: true,
            show_audio_panel: false,
            show_navmesh: false,
            left_panel_width: 260.0,
            right_panel_width: 340.0,

            active_workspace: Workspace::default(),
            workspace_layouts: BTreeMap::new(),
            theme: Theme::default(),
            hotkeys: HotkeyMap::default(),

            save_path: "scene.ron".to_string(),
            prefabs_dir: "prefabs".to_string(),
            fbx_export_path: "scene.fbx".to_string(),
            fly_speed: 15.0,
            fly_sensitivity: 0.0025,
            gizmo_snap: false,
            palette_keep_active: false,
            palette_snap_to_grid: true,
            palette_grid_step: 0.5,
            recent_scenes: Vec::new(),
            camera_bookmarks: CameraBookmarks::new(),
            postfx: PostFx::default(),
            audio_bus_volumes: HashMap::new(),
        }
    }
}

impl EditorSettings {
    pub fn load(path: impl AsRef<Path>) -> Self {
        let path = path.as_ref();
        let Ok(text) = std::fs::read_to_string(path) else {
            return Self::default();
        };
        match ron::from_str::<Self>(&text) {
            Ok(mut s) => {
                s.migrate();
                log::info!("Editor settings loaded from {}", path.display());
                s
            }
            Err(e) => {
                log::error!(
                    "Failed to parse editor settings '{}': {}. Using defaults.",
                    path.display(),
                    e
                );
                let backup = path.with_extension("ron.bak");
                match std::fs::rename(path, &backup) {
                    Ok(()) => log::warn!(
                        "Corrupt editor settings backed up to {}",
                        backup.display()
                    ),
                    Err(io_err) => log::warn!(
                        "Could not back up corrupt settings to {}: {}",
                        backup.display(),
                        io_err
                    ),
                }
                Self::default()
            }
        }
    }

    /// Миграция старых форматов к текущему. Вызывается после парсинга.
    fn migrate(&mut self) {
        if self.format < 1 {
            // Версия 1 — исходный формат (без поля `format`).
            self.format = 1;
        }
        // Будущие миграции:
        // if self.format < 2 { ...; self.format = 2; }
    }

    pub fn save(&self, path: impl AsRef<Path>) -> std::io::Result<()> {
        let path = path.as_ref();
        let text = ron::ser::to_string_pretty(self, ron::ser::PrettyConfig::default())
            .map_err(std::io::Error::other)?;
        std::fs::write(path, text).map_err(|e| {
            log::warn!(
                "Failed to write editor settings to {}: {}",
                path.display(),
                e
            );
            e
        })
    }

    pub fn push_recent_scene(&mut self, path: &str) {
        self.recent_scenes.retain(|p| p != path);
        self.recent_scenes.insert(0, path.to_string());
        self.recent_scenes.truncate(MAX_RECENT);
    }
}