mod gpu_types;
mod passes;
mod size_dep;
pub mod atmosphere;
pub mod probe;

pub use gpu_types::{
    AtmosphereParams, ClusterParams, DofParams, GpuLight, GpuPointLight, LensFlareParams, MeshDraw,
    MotionBlurParams, ParticleInstance, PostFx, Tonemapper, MAX_DIR_LIGHTS,
    MAX_POINT_LIGHTS, CLUSTER_GRID_Z, CLUSTER_TILE_SIZE, MAX_LIGHTS_PER_CLUSTER,
    MAX_POINT_LIGHTS_CLUSTERED,
};

use std::collections::HashMap;
use std::sync::Arc;
use glam::{Mat4, Vec2, Vec3};
use winit::window::Window;

use crate::render::camera::{Camera3D, CameraMode};
use crate::render::csm::{self, CASCADE_COUNT};
use crate::render::decal::{DecalDraw, DecalInstance};
use crate::render::ibl;
use crate::render::line::{LineBuffer, LineVertex};
use crate::render::material::{Material, MaterialRegistry, SamplerDesc};
use crate::render::mesh::{InstanceData, Mesh, Vertex3D};
use crate::render::shadow_cube;
use crate::render::texture::Texture;
use crate::ui::{UiGlobal, UiQuad};

use gpu_types::*;
use size_dep::{build_size_dependent, SizeDependent};

pub struct EguiFrameData<'a> {
    pub renderer: &'a mut egui_wgpu::Renderer,
    pub clipped_primitives: Vec<egui::ClippedPrimitive>,
    pub pixels_per_point: f32,
}

pub struct Renderer {
    pub surface: wgpu::Surface<'static>,
    pub device: wgpu::Device,
    pub queue: wgpu::Queue,
    pub config: wgpu::SurfaceConfiguration,
    pub size: winit::dpi::PhysicalSize<u32>,

    #[allow(dead_code)] camera_layout: wgpu::BindGroupLayout,
    #[allow(dead_code)] lights_layout: wgpu::BindGroupLayout,
    #[allow(dead_code)] shadow_pass_layout: wgpu::BindGroupLayout,
    shadow2_layout: wgpu::BindGroupLayout,
    contact_shadow_layout: wgpu::BindGroupLayout,
    contact_shadow_uniform: wgpu::Buffer,
    contact_shadow_pipeline: wgpu::RenderPipeline,
    texture_layout: wgpu::BindGroupLayout,
    material_layout: wgpu::BindGroupLayout,
    ssao_layout: wgpu::BindGroupLayout,
    lighting_layout: wgpu::BindGroupLayout,
    bloom_layout: wgpu::BindGroupLayout,
    tonemap_layout: wgpu::BindGroupLayout,
    debug_layout: wgpu::BindGroupLayout,
    debug_depth_layout: wgpu::BindGroupLayout,
    #[allow(dead_code)] skybox_layout: wgpu::BindGroupLayout,
    taa_layout: wgpu::BindGroupLayout,
    lens_flare_layout: wgpu::BindGroupLayout,
    dof_layout: wgpu::BindGroupLayout,
    motion_blur_layout: wgpu::BindGroupLayout,

    // Sprint 4: clustered lighting
    cluster_layout: wgpu::BindGroupLayout,
    cluster_lighting_layout: wgpu::BindGroupLayout,
    cluster_pipeline: wgpu::ComputePipeline,
    cluster_params_buffer: wgpu::Buffer,

    // Sprint 5: atmosphere
    // FIX: `atmosphere_layout` используется только в `reload_shaders`
    // (debug-only). В release-сборке поле «записано, но не прочитано» —
    // allow(dead_code) глушит warning.
    #[allow(dead_code)]
    atmosphere_layout: wgpu::BindGroupLayout,
    atmosphere_pipeline: wgpu::RenderPipeline,
    atmosphere_uniform: wgpu::Buffer,
    atmosphere_bind_group: wgpu::BindGroup,
    pub atmosphere_settings: atmosphere::AtmosphereSettings,

    // Sprint 8: reflection probes
    pub probes: Vec<probe::ProbeCubemap>,
    probe_bake_pipeline: wgpu::RenderPipeline,
    probe_bake_uniform: wgpu::Buffer,
    // FIX: все три используются только в `reload_shaders` / `bake_probe`
    // (debug + runtime-bake path). В release `probe_bake_layout` и
    // `probe_bake_bind_group` не читаются — allow(dead_code).
    #[allow(dead_code)]
    probe_bake_layout: wgpu::BindGroupLayout,
    #[allow(dead_code)]
    probe_bake_bind_group: wgpu::BindGroup,
    probe_bake_depth_view: wgpu::TextureView,
    _probe_bake_depth_tex: wgpu::Texture,
    // FIX: `probe_bake_pipeline` собирается из `forward_transparent.wgsl::fs_main`,
    // у которого два выхода (@location(0) color, @location(1) motion). Pipeline
    // обязан объявить два target'а, а render pass — два attachment'а. Motion
    // для probe не нужен (write_mask: empty в pipeline), но валидатор wgpu
    // требует соответствия один-в-один. Держим общую dummy-текстуру MOTION_FORMAT
    // 256×256, используется для всех 6 граней всех probe'ов.
    probe_bake_motion_view: wgpu::TextureView,
    _probe_bake_motion_tex: wgpu::Texture,
    // `probe_lighting_layout` используется только в `make_lighting_pipeline`
    // (при создании и в reload_shaders — оба debug-пути).
    #[allow(dead_code)]
    probe_lighting_layout: wgpu::BindGroupLayout,
    // `probe_lighting_uniform` и `probe_lighting_bind_group` теперь читаются
    // в `render()` и `encode_lighting_pass` соответственно — allow не нужен.
    probe_lighting_uniform: wgpu::Buffer,
    probe_lighting_bind_group: wgpu::BindGroup,

    volumetric_compute_layout: wgpu::BindGroupLayout,
    volumetric_composite_layout: wgpu::BindGroupLayout,
    volumetric_uniform: wgpu::Buffer,
    volumetric_pipeline: wgpu::ComputePipeline,
    volumetric_composite_pipeline: wgpu::RenderPipeline,

    camera_buffer: wgpu::Buffer,
    camera_bind_group: wgpu::BindGroup,

    lights_buffer: wgpu::Buffer,
    lights_bind_group: wgpu::BindGroup,

    shadow_pass_buffer: wgpu::Buffer,
    shadow_pass_bind_group: wgpu::BindGroup,
    shadow_pass_stride: u64,

    csm_array_view: wgpu::TextureView,
    csm_cascade_views: [wgpu::TextureView; CASCADE_COUNT],
    csm_sampler: wgpu::Sampler,

    cube_shadow_array_view: wgpu::TextureView,
    cube_shadow_face_views: [[wgpu::TextureView; 6]; MAX_SHADOW_CUBES],
    cube_shadow_sampler: wgpu::Sampler,

    material_bind_groups: HashMap<String, MaterialGpu>,
    default_material_bind_group: MaterialGpu,

    sampler_cache: HashMap<SamplerDesc, Arc<wgpu::Sampler>>,
    pub skeleton_buffers: HashMap<String, Arc<wgpu::Buffer>>,

    fallback_texture: Texture,
    fallback_mr: Texture,
    fallback_normal: Texture,
    fallback_emissive: Texture,

    gbuffer_pipeline: wgpu::RenderPipeline,
    gbuffer_pipeline_double_sided: wgpu::RenderPipeline,
    shadow_pipeline: wgpu::RenderPipeline,
    shadow_pipeline_double_sided: wgpu::RenderPipeline,
    line_pipeline: wgpu::RenderPipeline,
    particles_pipeline: wgpu::RenderPipeline,
    transparent_pipeline: wgpu::RenderPipeline,
    transparent_pipeline_double_sided: wgpu::RenderPipeline,
    lighting_pipeline: wgpu::RenderPipeline,
    ssao_pipeline: wgpu::RenderPipeline,
    ssao_blur_pipeline: wgpu::RenderPipeline,
    bloom_prefilter_pipeline: wgpu::RenderPipeline,
    bloom_downsample_pipeline: wgpu::RenderPipeline,
    bloom_upsample_pipeline: wgpu::RenderPipeline,
    tonemap_pipeline: wgpu::RenderPipeline,
    fxaa_pipeline: wgpu::RenderPipeline,
    skybox_pipeline: wgpu::RenderPipeline,
    taa_pipeline: wgpu::RenderPipeline,
    decal_pipeline: wgpu::RenderPipeline,

    debug2d_pipeline: wgpu::RenderPipeline,
    debug_depth_pipeline: wgpu::RenderPipeline,
    csm_debug_bind_group: wgpu::BindGroup,

    tonemap_uniform: wgpu::Buffer,
    ssao_uniform: wgpu::Buffer,

    lens_flare_uniform: wgpu::Buffer,
    lens_flare_pipeline: wgpu::RenderPipeline,
    lens_flare_bind_group: wgpu::BindGroup,

    dof_uniform: wgpu::Buffer,
    dof_pipeline: wgpu::RenderPipeline,
    dof_bind_group: wgpu::BindGroup,

    motion_blur_uniform: wgpu::Buffer,
    motion_blur_pipeline: wgpu::RenderPipeline,
    motion_blur_bind_group: wgpu::BindGroup,

    skybox_uniform: wgpu::Buffer,
    skybox_bind_group: wgpu::BindGroup,

    _ssao_noise_tex: wgpu::Texture,
    ssao_noise_view: wgpu::TextureView,

    ibl: Option<ibl::IblResources>,

    sd: SizeDependent,

    instance_buffer: wgpu::Buffer,
    instance_capacity: u64,
    pub line_buffer: LineBuffer,

    particles_instance_buffer: wgpu::Buffer,
    particles_instance_capacity: u64,

    decal_texture_layout: wgpu::BindGroupLayout,
    decal_depth_layout: wgpu::BindGroupLayout,
    decal_depth_bind_group: wgpu::BindGroup,
    decal_texture_bind_groups: HashMap<String, wgpu::BindGroup>,
    decal_instance_buffer: wgpu::Buffer,
    decal_instance_capacity: u64,
    pub meshes: HashMap<String, Mesh>,
    pub materials: MaterialRegistry,
    pub textures: HashMap<String, Texture>,
    default_material: Material,
    pub terrain: Option<crate::render::terrain::Heightmap>,
    skybox_time: f32,
    taa_frame_index: u32,
    taa_prev_view_proj: Mat4,
    taa_reset_frames: u32,
    taa_prev_camera_mode: Option<CameraMode>,
    taa_prev_jitter_px: Vec2,
    taa_prev_enabled: bool,
    pub gpu_particles: gpu_particles::GpuParticleSystem,
    last_render_time: f32,
    pub last_draw_count: usize,
    pub last_instance_count: usize,
    pub features: wgpu::Features,
    render_scale: f32,
    ui_pipeline: wgpu::RenderPipeline,
    ui_global_buffer: wgpu::Buffer,
    ui_global_bind_group: wgpu::BindGroup,
    ui_instance_buffer: wgpu::Buffer,
    ui_instance_capacity: u64,
    _ui_font_atlas_tex: wgpu::Texture,
    pub font: Arc<crate::ui::font::Font>,
}

fn draw_center(d: &MeshDraw) -> Vec3 {
    if d.instances.is_empty() { return Vec3::ZERO; }
    let mut sum = Vec3::ZERO;
    for inst in &d.instances {
        let m = &inst.model;
        sum += Vec3::new(m[3][0], m[3][1], m[3][2]);
    }
    sum / d.instances.len() as f32
}

fn sort_draws_for_render(draws: &[MeshDraw], cam_pos: Vec3) -> Vec<MeshDraw> {
    let mut v: Vec<MeshDraw> = draws.iter().map(|d| MeshDraw {
        mesh: d.mesh.clone(),
        instances: d.instances.clone(),
        texture: d.texture.clone(),
        blend: d.blend,
        double_sided: d.double_sided,
    }).collect();
    v.sort_by_key(|d| d.blend);
    let blend_start = v.partition_point(|d| !d.blend);
    if blend_start < v.len() {
        v[blend_start..].sort_by(|a, b| {
            let da = draw_center(a).distance_squared(cam_pos);
            let db = draw_center(b).distance_squared(cam_pos);
            db.partial_cmp(&da).unwrap_or(std::cmp::Ordering::Equal)
        });
    }
    v
}

impl Renderer {
    pub async fn new(window: Arc<Window>) -> Self {
        let size = window.inner_size();
        let instance = wgpu::Instance::default();
        let surface = instance.create_surface(window.clone()).unwrap();
        let adapter = instance.request_adapter(&wgpu::RequestAdapterOptions {
            power_preference: wgpu::PowerPreference::HighPerformance,
            compatible_surface: Some(&surface),
            force_fallback_adapter: false,
            apply_limit_buckets: false,
        }).await.unwrap();

        let adapter_limits = adapter.limits();

        let mut device_limits = wgpu::Limits::default();

        device_limits.max_vertex_attributes =
            adapter_limits.max_vertex_attributes.min(32);

        const WANTED_BIND_GROUPS: u32 = 5;
        device_limits.max_bind_groups =
            adapter_limits.max_bind_groups.min(WANTED_BIND_GROUPS);

        if device_limits.max_bind_groups < WANTED_BIND_GROUPS {
            panic!(
                "GPU supports only {} bind groups, but the engine needs {} \
                 (deferred_lighting.wgsl uses @group(4) for reflection probes). \
                 Update GPU driver, or run on a discrete GPU.",
                adapter_limits.max_bind_groups,
                WANTED_BIND_GROUPS,
            );
        }

        log::info!(
            "Renderer: adapter max_bind_groups={} max_vertex_attributes={}, \
             requested bind_groups={} vertex_attributes={}",
            adapter_limits.max_bind_groups,
            adapter_limits.max_vertex_attributes,
            device_limits.max_bind_groups,
            device_limits.max_vertex_attributes,
        );

        let desired_features = wgpu::Features::TEXTURE_BINDING_ARRAY
            | wgpu::Features::SAMPLED_TEXTURE_AND_STORAGE_BUFFER_ARRAY_NON_UNIFORM_INDEXING
            | wgpu::Features::STORAGE_TEXTURE_ARRAY_NON_UNIFORM_INDEXING
            | wgpu::Features::BUFFER_BINDING_ARRAY
            | wgpu::Features::STORAGE_RESOURCE_BINDING_ARRAY
            | wgpu::Features::INDIRECT_FIRST_INSTANCE
            | wgpu::Features::MULTI_DRAW_INDIRECT_COUNT
            | wgpu::Features::CONSERVATIVE_RASTERIZATION
            | wgpu::Features::SHADER_F16
            | wgpu::Features::TIMESTAMP_QUERY
            | wgpu::Features::TIMESTAMP_QUERY_INSIDE_ENCODERS
            | wgpu::Features::DEPTH_CLIP_CONTROL
            | wgpu::Features::TEXTURE_ADAPTER_SPECIFIC_FORMAT_FEATURES;
        let features = adapter.features() & desired_features;
        log::info!("Renderer: features enabled = {:?}", features);

        let (device, queue) = adapter.request_device(&wgpu::DeviceDescriptor {
            label: Some("device"),
            required_features: features,
            required_limits: device_limits,
            memory_hints: wgpu::MemoryHints::default(),
            trace: wgpu::Trace::Off,
            experimental_features: wgpu::ExperimentalFeatures::disabled(),
        }).await.unwrap();

        let caps = surface.get_capabilities(&adapter);
        let format = caps.formats.iter().copied()
            .find(|f| !f.is_srgb())
            .or_else(|| caps.formats.iter().copied().find(|f| f.is_srgb()))
            .unwrap_or(caps.formats[0]);
        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode: wgpu::PresentMode::AutoVsync,
            alpha_mode: caps.alpha_modes[0],
            view_formats: vec![],
            desired_maximum_frame_latency: 1,
            color_space: wgpu::SurfaceColorSpace::Srgb,
        };
        surface.configure(&device, &config);

        let lens_flare_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("lens_flare_layout"),
            entries: &[bgl_tex_frag(0), bgl_sampler_frag(1), bgl_uniform_frag(2)],
        });
        let dof_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("dof_layout"),
            entries: &[bgl_tex_frag(0), bgl_tex_frag(1), bgl_sampler_frag(2), bgl_uniform_frag(3)],
        });
        let motion_blur_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("motion_blur_layout"),
            entries: &[bgl_tex_frag(0), bgl_tex_frag(1), bgl_sampler_frag(2), bgl_uniform_frag(3)],
        });

        let camera_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("camera_layout"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX_FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });
        let lights_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("lights_layout"),
            entries: &[bgl_uniform_frag(0)],
        });
        let shadow_pass_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("shadow_pass_layout"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: true,
                    min_binding_size: wgpu::BufferSize::new(
                        std::mem::size_of::<LightsUniform>() as u64,
                    ),
                },
                count: None,
            }],
        });
        let shadow2_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("shadow2_layout"),
            entries: &[
                bgl_depth_2darray(0), bgl_cmp_sampler(1),
                bgl_depth_cubearray(2), bgl_cmp_sampler(3),
                bgl_tex_frag(4), bgl_sampler_frag(5),
                bgl_cube_frag(6), bgl_cube_frag(7),
                bgl_tex_frag(8), bgl_sampler_frag(9), bgl_cube_frag(10),
                bgl_tex_frag(11),
            ],
        });

        let contact_shadow_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("contact_shadow_layout"),
            entries: &[
                bgl_depth_2d(0),
                bgl_sampler_nonfiltering_frag(1),
                bgl_uniform_frag(2),
                bgl_uniform_frag(3),
            ],
        });
        let contact_shadow_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("contact_shadow_uniform"),
            size: std::mem::size_of::<ContactShadowParams>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let contact_shadow_pipeline = {
            let src = crate::shader_source!("src/render/shaders/contact_shadows.wgsl")
                .expect("contact_shadows.wgsl not found");
            let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
                label: Some("contact_shadow_shader"),
                source: wgpu::ShaderSource::Wgsl(src.into()),
            });
            let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some("contact_shadow_pipeline_layout"),
                bind_group_layouts: &[Some(&contact_shadow_layout)],
                immediate_size: 0,
            });
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: Some("contact_shadow_pipeline"),
                layout: Some(&layout),
                vertex: wgpu::VertexState {
                    module: &shader, entry_point: Some("vs_main"),
                    buffers: &[], compilation_options: Default::default(),
                },
                fragment: Some(wgpu::FragmentState {
                    module: &shader, entry_point: Some("fs_main"),
                    targets: &[Some(wgpu::ColorTargetState {
                        format: CONTACT_SHADOW_FORMAT,
                        blend: None,
                        write_mask: wgpu::ColorWrites::ALL,
                    })],
                    compilation_options: Default::default(),
                }),
                primitive: wgpu::PrimitiveState::default(),
                depth_stencil: None,
                multisample: wgpu::MultisampleState::default(),
                multiview_mask: None,
                cache: None,
            })
        };

        let texture_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("texture_layout"),
            entries: &[bgl_tex_frag(0), bgl_sampler_frag(1)],
        });
        let material_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("material_layout"),
            entries: &[
                bgl_tex_frag(0), bgl_tex_frag(1), bgl_tex_frag(2), bgl_tex_frag(3),
                bgl_sampler_frag(4), bgl_uniform_frag(5),
                wgpu::BindGroupLayoutEntry {
                    binding: 6,
                    visibility: wgpu::ShaderStages::VERTEX,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: wgpu::BufferSize::new(
                            std::mem::size_of::<SkeletonUniform>() as u64,
                        ),
                    },
                    count: None,
                },
            ],
        });
        let ssao_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("ssao_layout"),
            entries: &[
                bgl_tex_frag(0), bgl_tex_frag(1), bgl_sampler_frag(2),
                bgl_uniform_frag(3), bgl_tex_frag(4),
            ],
        });
        let lighting_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("lighting_layout"),
            entries: &[
                bgl_tex_frag(0), bgl_tex_frag(1), bgl_tex_frag(2),
                bgl_depth_2d(3), bgl_sampler_frag(4), bgl_uniform_frag(5),
            ],
        });
        let bloom_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("bloom_layout"),
            entries: &[bgl_tex_frag(0), bgl_sampler_frag(1), bgl_uniform_frag(2)],
        });
        let tonemap_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("tonemap_layout"),
            entries: &[bgl_tex_frag(0), bgl_tex_frag(1), bgl_sampler_frag(2), bgl_uniform_frag(3)],
        });
        let debug_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("debug_layout"),
            entries: &[bgl_tex_frag(0), bgl_sampler_frag(1), bgl_uniform_frag(2)],
        });
        let debug_depth_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("debug_depth_layout"),
            entries: &[bgl_depth_2darray(0), bgl_sampler_nonfiltering_frag(1)],
        });
        let skybox_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("skybox_layout"),
            entries: &[bgl_uniform_frag(0), bgl_cube_frag(1), bgl_sampler_frag(2), bgl_uniform_frag(3)],
        });
        let taa_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("taa_layout"),
            entries: &[
                bgl_tex_frag(0), bgl_tex_frag(1), bgl_tex_frag(2),
                bgl_sampler_frag(3), bgl_uniform_frag(4),
            ],
        });
        let volumetric_compute_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("volumetric_compute_layout"),
            entries: &[
                bgl_uniform_compute(0), bgl_uniform_compute(1), bgl_uniform_compute(2),
                wgpu::BindGroupLayoutEntry {
                    binding: 3, visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Depth,
                        view_dimension: wgpu::TextureViewDimension::D2Array,
                        multisampled: false,
                    }, count: None,
                },
                bgl_cmp_sampler_compute(4),
                wgpu::BindGroupLayoutEntry {
                    binding: 5, visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::StorageTexture {
                        access: wgpu::StorageTextureAccess::WriteOnly,
                        format: VOLUMETRIC_FORMAT,
                        view_dimension: wgpu::TextureViewDimension::D3,
                    }, count: None,
                },
            ],
        });
        let volumetric_composite_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("volumetric_composite_layout"),
            entries: &[
                bgl_tex_frag(0), bgl_tex3d_frag(1), bgl_sampler_frag(2),
                bgl_depth_2d(3), bgl_uniform_frag(4),
                bgl_tex_frag(5), bgl_tex_frag(6), bgl_tex_frag(7), bgl_uniform_frag(8),
            ],
        });
        let decal_texture_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("decal_texture_layout"),
            entries: &[bgl_tex_frag(0), bgl_sampler_frag(1)],
        });
        let decal_depth_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("decal_depth_layout"),
            entries: &[bgl_depth_2d(0)],
        });

        let ui_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("ui_layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::VERTEX_FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
                bgl_tex_frag(1),
                bgl_sampler_frag(2),
            ],
        });

        let cluster_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("cluster_layout"),
            entries: &[
                bgl_uniform_compute(0), bgl_uniform_compute(1),
                wgpu::BindGroupLayoutEntry {
                    binding: 2, visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Storage { read_only: true },
                        has_dynamic_offset: false, min_binding_size: None,
                    }, count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 3, visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Storage { read_only: false },
                        has_dynamic_offset: false, min_binding_size: None,
                    }, count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 4, visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Storage { read_only: false },
                        has_dynamic_offset: false, min_binding_size: None,
                    }, count: None,
                },
            ],
        });
        let cluster_lighting_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("cluster_lighting_layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0, visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Storage { read_only: true },
                        has_dynamic_offset: false, min_binding_size: None,
                    }, count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1, visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Storage { read_only: true },
                        has_dynamic_offset: false, min_binding_size: None,
                    }, count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 2, visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Storage { read_only: true },
                        has_dynamic_offset: false, min_binding_size: None,
                    }, count: None,
                },
                bgl_uniform_frag(3),
            ],
        });

        let cluster_params_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("cluster_params_buffer"),
            size: std::mem::size_of::<ClusterParams>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let cluster_pipeline = {
            let src = crate::shader_source!("src/render/shaders/cluster_assign.wgsl")
                .expect("cluster_assign.wgsl not found");
            let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
                label: Some("cluster_assign_shader"),
                source: wgpu::ShaderSource::Wgsl(src.into()),
            });
            let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some("cluster_pipeline_layout"),
                bind_group_layouts: &[Some(&cluster_layout)],
                immediate_size: 0,
            });
            device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
                label: Some("cluster_pipeline"),
                layout: Some(&layout),
                module: &shader,
                entry_point: Some("cs_main"),
                compilation_options: Default::default(),
                cache: None,
            })
        };

        let camera_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("camera_buffer"),
            size: std::mem::size_of::<CameraUniform>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let camera_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("camera_bind_group"),
            layout: &camera_layout,
            entries: &[wgpu::BindGroupEntry { binding: 0, resource: camera_buffer.as_entire_binding() }],
        });

        let atmosphere_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("atmosphere_layout"),
            entries: &[bgl_uniform_frag(0), bgl_uniform_frag(1)],
        });
        let atmosphere_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("atmosphere_uniform"),
            size: std::mem::size_of::<AtmosphereParams>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let atmosphere_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("atmosphere_bg"),
            layout: &atmosphere_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: camera_buffer.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: atmosphere_uniform.as_entire_binding() },
            ],
        });
        let atmosphere_pipeline = {
            let src = crate::shader_source!("src/render/shaders/sky_atmosphere.wgsl")
                .expect("sky_atmosphere.wgsl not found");
            let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
                label: Some("atmosphere_shader"),
                source: wgpu::ShaderSource::Wgsl(src.into()),
            });
            let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some("atmosphere_pipeline_layout"),
                bind_group_layouts: &[Some(&atmosphere_layout)],
                immediate_size: 0,
            });
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: Some("atmosphere_pipeline"),
                layout: Some(&layout),
                vertex: wgpu::VertexState {
                    module: &shader, entry_point: Some("vs_main"),
                    buffers: &[], compilation_options: Default::default(),
                },
                fragment: Some(wgpu::FragmentState {
                    module: &shader, entry_point: Some("fs_main"),
                    targets: &[Some(wgpu::ColorTargetState {
                        format: HDR_FORMAT, blend: None,
                        write_mask: wgpu::ColorWrites::ALL,
                    })],
                    compilation_options: Default::default(),
                }),
                primitive: wgpu::PrimitiveState::default(),
                depth_stencil: Some(wgpu::DepthStencilState {
                    format: DEPTH_FORMAT,
                    depth_write_enabled: Some(false),
                    depth_compare: Some(wgpu::CompareFunction::LessEqual),
                    stencil: wgpu::StencilState::default(),
                    bias: wgpu::DepthBiasState::default(),
                }),
                multisample: wgpu::MultisampleState::default(),
                multiview_mask: None,
                cache: None,
            })
        };

        let probe_bake_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("probe_bake_layout"),
            entries: &[bgl_uniform_frag(0)],
        });
        let probe_bake_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("probe_bake_uniform"),
            size: std::mem::size_of::<probe::ProbeBakeUniform>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let probe_bake_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("probe_bake_bg"),
            layout: &probe_bake_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: probe_bake_uniform.as_entire_binding(),
            }],
        });

        let probe_bake_depth_tex = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("probe_bake_depth"),
            size: wgpu::Extent3d {
                width: probe::PROBE_FACE_SIZE,
                height: probe::PROBE_FACE_SIZE,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: DEPTH_FORMAT,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            view_formats: &[],
        });
        let probe_bake_depth_view = probe_bake_depth_tex
            .create_view(&wgpu::TextureViewDescriptor::default());

        let probe_bake_motion_tex = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("probe_bake_motion"),
            size: wgpu::Extent3d {
                width: probe::PROBE_FACE_SIZE,
                height: probe::PROBE_FACE_SIZE,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: MOTION_FORMAT,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            view_formats: &[],
        });
        let probe_bake_motion_view = probe_bake_motion_tex
            .create_view(&wgpu::TextureViewDescriptor::default());

        let probe_bake_pipeline = {
            let src = crate::shader_source!("src/render/shaders/forward_transparent.wgsl")
                .expect("forward_transparent.wgsl not found");
            let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
                label: Some("probe_bake_shader"),
                source: wgpu::ShaderSource::Wgsl(src.into()),
            });
            let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some("probe_bake_pipeline_layout"),
                bind_group_layouts: &[
                    Some(&camera_layout),
                    Some(&lights_layout),
                    Some(&shadow2_layout),
                    Some(&material_layout),
                ],
                immediate_size: 0,
            });
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: Some("probe_bake_pipeline"),
                layout: Some(&layout),
                vertex: wgpu::VertexState {
                    module: &shader,
                    entry_point: Some("vs_main"),
                    buffers: &[Some(Vertex3D::layout()), Some(InstanceData::layout())],
                    compilation_options: Default::default(),
                },
                fragment: Some(wgpu::FragmentState {
                    module: &shader,
                    entry_point: Some("fs_main"),
                    targets: &[
                        Some(wgpu::ColorTargetState {
                            format: HDR_FORMAT,
                            blend: Some(wgpu::BlendState::REPLACE),
                            write_mask: wgpu::ColorWrites::ALL,
                        }),
                        Some(wgpu::ColorTargetState {
                            format: MOTION_FORMAT,
                            blend: None,
                            write_mask: wgpu::ColorWrites::empty(),
                        }),
                    ],
                    compilation_options: Default::default(),
                }),
                primitive: wgpu::PrimitiveState {
                    topology: wgpu::PrimitiveTopology::TriangleList,
                    front_face: wgpu::FrontFace::Ccw,
                    cull_mode: Some(wgpu::Face::Back),
                    ..Default::default()
                },
                depth_stencil: Some(wgpu::DepthStencilState {
                    format: DEPTH_FORMAT,
                    depth_write_enabled: Some(true),
                    depth_compare: Some(wgpu::CompareFunction::Less),
                    stencil: wgpu::StencilState::default(),
                    bias: wgpu::DepthBiasState::default(),
                }),
                multisample: wgpu::MultisampleState::default(),
                multiview_mask: None,
                cache: None,
            })
        };

        let probe_lighting_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("probe_lighting_layout"),
            entries: &[
                bgl_cube_frag(0),
                bgl_cube_frag(1),
                bgl_cube_frag(2),
                bgl_cube_frag(3),
                bgl_sampler_frag(4),
                bgl_uniform_frag(5),
            ],
        });
        let probe_lighting_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("probe_lighting_uniform"),
            size: std::mem::size_of::<ProbeLightingUniform>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let mut probes: Vec<probe::ProbeCubemap> = Vec::with_capacity(probe::MAX_REFLECTION_PROBES);
        for i in 0..probe::MAX_REFLECTION_PROBES {
            probes.push(probe::ProbeCubemap::new(
                &device,
                &format!("reflection_probe_{}", i),
            ));
        }

        let probe_lighting_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("probe_lighting_bg"),
            layout: &probe_lighting_layout,
            entries: &[
                wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::TextureView(&probes[0].cube_view),
                },
                wgpu::BindGroupEntry {
                    binding: 1,
                    resource: wgpu::BindingResource::TextureView(&probes[1].cube_view),
                },
                wgpu::BindGroupEntry {
                    binding: 2,
                    resource: wgpu::BindingResource::TextureView(&probes[2].cube_view),
                },
                wgpu::BindGroupEntry {
                    binding: 3,
                    resource: wgpu::BindingResource::TextureView(&probes[3].cube_view),
                },
                wgpu::BindGroupEntry {
                    binding: 4,
                    resource: wgpu::BindingResource::Sampler(&probes[0].sampler),
                },
                wgpu::BindGroupEntry {
                    binding: 5,
                    resource: probe_lighting_uniform.as_entire_binding(),
                },
            ],
        });

        let lights_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("lights_buffer"),
            size: std::mem::size_of::<LightsUniform>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let lights_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("lights_bind_group"),
            layout: &lights_layout,
            entries: &[wgpu::BindGroupEntry { binding: 0, resource: lights_buffer.as_entire_binding() }],
        });

        let align = device.limits().min_uniform_buffer_offset_alignment as u64;
        let light_size = std::mem::size_of::<LightsUniform>() as u64;
        let shadow_pass_stride = light_size.div_ceil(align) * align;

        let shadow_pass_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("shadow_pass_buffer"),
            size: shadow_pass_stride * SHADOW_SLOT_COUNT,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let shadow_pass_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("shadow_pass_bind_group"),
            layout: &shadow_pass_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: wgpu::BindingResource::Buffer(wgpu::BufferBinding {
                    buffer: &shadow_pass_buffer, offset: 0,
                    size: wgpu::BufferSize::new(light_size),
                }),
            }],
        });

        let tonemap_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("tonemap_uniform"),
            size: std::mem::size_of::<TonemapParams>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let ssao_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("ssao_uniform"),
            size: std::mem::size_of::<SsaoUniform>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let lens_flare_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("lens_flare_uniform"),
            size: std::mem::size_of::<LensFlareParams>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let dof_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("dof_uniform"),
            size: std::mem::size_of::<DofParams>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let motion_blur_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("motion_blur_uniform"),
            size: std::mem::size_of::<MotionBlurParams>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let skybox_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("skybox_uniform"),
            size: std::mem::size_of::<SkyboxParams>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let volumetric_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("volumetric_uniform"),
            size: std::mem::size_of::<VolumetricParams>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let csm_texture = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("csm_texture"),
            size: wgpu::Extent3d {
                width: csm::CASCADE_SIZE, height: csm::CASCADE_SIZE,
                depth_or_array_layers: CASCADE_COUNT as u32,
            },
            mip_level_count: 1, sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: DEPTH_FORMAT,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        });
        let csm_array_view = csm_texture.create_view(&wgpu::TextureViewDescriptor {
            label: Some("csm_array_view"),
            dimension: Some(wgpu::TextureViewDimension::D2Array),
            base_array_layer: 0,
            array_layer_count: Some(CASCADE_COUNT as u32),
            ..Default::default()
        });
        let csm_cascade_views: [wgpu::TextureView; CASCADE_COUNT] = std::array::from_fn(|i| {
            csm_texture.create_view(&wgpu::TextureViewDescriptor {
                label: Some("csm_cascade_view"),
                dimension: Some(wgpu::TextureViewDimension::D2),
                base_array_layer: i as u32,
                array_layer_count: Some(1),
                ..Default::default()
            })
        });
        let csm_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("csm_sampler"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            mipmap_filter: wgpu::MipmapFilterMode::Linear,
            compare: Some(wgpu::CompareFunction::LessEqual),
            ..Default::default()
        });

        let cube_texture = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("cube_shadow_texture"),
            size: wgpu::Extent3d {
                width: shadow_cube::CUBE_SIZE, height: shadow_cube::CUBE_SIZE,
                depth_or_array_layers: (6 * MAX_SHADOW_CUBES) as u32,
            },
            mip_level_count: 1, sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: DEPTH_FORMAT,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        });
        let cube_shadow_array_view = cube_texture.create_view(&wgpu::TextureViewDescriptor {
            label: Some("cube_shadow_array_view"),
            dimension: Some(wgpu::TextureViewDimension::CubeArray),
            base_array_layer: 0,
            array_layer_count: Some((6 * MAX_SHADOW_CUBES) as u32),
            base_mip_level: 0,
            mip_level_count: Some(1),
            ..Default::default()
        });
        let cube_shadow_face_views: [[wgpu::TextureView; 6]; MAX_SHADOW_CUBES] =
            std::array::from_fn(|cube| {
                std::array::from_fn(|face| {
                    cube_texture.create_view(&wgpu::TextureViewDescriptor {
                        label: Some("cube_shadow_face_view"),
                        dimension: Some(wgpu::TextureViewDimension::D2),
                        base_array_layer: (cube * 6 + face) as u32,
                        array_layer_count: Some(1),
                        ..Default::default()
                    })
                })
            });
        let cube_shadow_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("cube_shadow_sampler"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            mipmap_filter: wgpu::MipmapFilterMode::Linear,
            compare: Some(wgpu::CompareFunction::LessEqual),
            ..Default::default()
        });

        let ibl = ibl::IblResources::load_or_default(&device, &queue, "assets/sky.hdr")
            .expect("IBL init failed");

        let skybox_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("skybox_bind_group"),
            layout: &skybox_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: camera_buffer.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&ibl.env_cube_view) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&ibl.env_sampler) },
                wgpu::BindGroupEntry { binding: 3, resource: skybox_uniform.as_entire_binding() },
            ],
        });

        let gbuffer_pipeline = make_gbuffer_pipeline(&device, &camera_layout, &material_layout, Some(wgpu::Face::Back)).expect("gbuffer pipeline");
        let gbuffer_pipeline_double_sided = make_gbuffer_pipeline(&device, &camera_layout, &material_layout, None).expect("gbuffer pipeline (double-sided)");
        let shadow_pipeline = make_shadow_pipeline(&device, &shadow_pass_layout, &material_layout, Some(wgpu::Face::Back)).expect("shadow pipeline");
        let shadow_pipeline_double_sided = make_shadow_pipeline(&device, &shadow_pass_layout, &material_layout, None).expect("shadow pipeline (double-sided)");
        let line_pipeline = make_line_pipeline(&device, &camera_layout).expect("line pipeline");
        let particles_pipeline = make_particles_pipeline(&device, &camera_layout).expect("particles pipeline");
        let transparent_pipeline = make_transparent_pipeline(&device, &camera_layout, &lights_layout, &shadow2_layout, &material_layout, Some(wgpu::Face::Back)).expect("transparent pipeline");
        let transparent_pipeline_double_sided = make_transparent_pipeline(&device, &camera_layout, &lights_layout, &shadow2_layout, &material_layout, None).expect("transparent pipeline (double-sided)");

        // FIX: `make_lighting_pipeline` теперь принимает 6 аргументов
        // (включая `probe_lighting_layout`) и создаёт 5 bind-group-layout'ов.
        let lighting_pipeline = make_lighting_pipeline(
            &device, &lighting_layout, &lights_layout, &shadow2_layout,
            &cluster_lighting_layout, &probe_lighting_layout,
        ).expect("lighting pipeline");

        let (ssao_pipeline, ssao_blur_pipeline) = make_ssao_pipelines(&device, &ssao_layout).expect("ssao pipelines");
        let (bloom_prefilter_pipeline, bloom_downsample_pipeline, bloom_upsample_pipeline) =
            make_bloom_chain_pipelines(&device, &bloom_layout).expect("bloom chain pipelines");
        let tonemap_pipeline = make_tonemap_pipeline(&device, &config, &tonemap_layout).expect("tonemap pipeline");
        let (debug2d_pipeline, debug_depth_pipeline) = make_debug_pipelines(&device, &config, &debug_layout, &debug_depth_layout).expect("debug pipelines");
        let fxaa_pipeline = make_fxaa_pipeline(&device, &config, &debug_layout).expect("fxaa pipeline");
        let skybox_pipeline = make_skybox_pipeline(&device, &skybox_layout).expect("skybox pipeline");
        let taa_pipeline = make_taa_pipeline(&device, &taa_layout).expect("taa pipeline");
        let decal_pipeline = make_decal_pipeline(&device, &camera_layout, &decal_texture_layout, &decal_depth_layout).expect("decal pipeline");
        let lens_flare_pipeline = make_lens_flare_pipeline(&device, &lens_flare_layout, HDR_FORMAT).expect("lens_flare pipeline");
        let dof_pipeline = make_dof_pipeline(&device, &dof_layout, HDR_FORMAT).expect("dof pipeline");
        let motion_blur_pipeline = make_motion_blur_pipeline(&device, &motion_blur_layout, HDR_FORMAT).expect("motion_blur pipeline");

        let volumetric_pipeline = {
            let src = crate::shader_source!("src/render/shaders/volumetric_fog.wgsl").expect("volumetric_fog.wgsl not found");
            let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
                label: Some("volumetric_fog_shader"),
                source: wgpu::ShaderSource::Wgsl(src.into()),
            });
            let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some("volumetric_pipeline_layout"),
                bind_group_layouts: &[Some(&volumetric_compute_layout)],
                immediate_size: 0,
            });
            device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
                label: Some("volumetric_pipeline"),
                layout: Some(&layout),
                module: &shader, entry_point: Some("cs_main"),
                compilation_options: Default::default(), cache: None,
            })
        };

        let volumetric_composite_pipeline = {
            let src = crate::shader_source!("src/render/shaders/volumetric_composite.wgsl").expect("volumetric_composite.wgsl not found");
            let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
                label: Some("volumetric_composite_shader"),
                source: wgpu::ShaderSource::Wgsl(src.into()),
            });
            let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some("volumetric_composite_pipeline_layout"),
                bind_group_layouts: &[Some(&volumetric_composite_layout)],
                immediate_size: 0,
            });
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: Some("volumetric_composite_pipeline"),
                layout: Some(&layout),
                vertex: wgpu::VertexState {
                    module: &shader, entry_point: Some("vs_main"),
                    buffers: &[], compilation_options: Default::default(),
                },
                fragment: Some(wgpu::FragmentState {
                    module: &shader, entry_point: Some("fs_main"),
                    targets: &[Some(wgpu::ColorTargetState {
                        format: HDR_FORMAT,
                        blend: Some(wgpu::BlendState::REPLACE),
                        write_mask: wgpu::ColorWrites::ALL,
                    })], compilation_options: Default::default(),
                }),
                primitive: wgpu::PrimitiveState::default(),
                depth_stencil: None,
                multisample: wgpu::MultisampleState::default(),
                multiview_mask: None, cache: None,
            })
        };

        let (ssao_noise_tex, ssao_noise_view) = create_noise_texture(&device, &queue);

        let initial_render_scale = 1.0_f32;
        let (iw, ih) = {
            let s = initial_render_scale.clamp(1.0, 2.0);
            (
                ((config.width as f32 * s).round() as u32).max(1),
                ((config.height as f32 * s).round() as u32).max(1),
            )
        };
        let mut internal_config = config.clone();
        internal_config.width = iw;
        internal_config.height = ih;

        let sd = build_size_dependent(
            &device, &internal_config,
            &bloom_layout, &tonemap_layout, &ssao_layout,
            &shadow2_layout, &debug_layout, &lighting_layout, &taa_layout,
            &volumetric_compute_layout, &volumetric_composite_layout,
            &contact_shadow_layout,
            &ssao_uniform, &volumetric_uniform,
            &contact_shadow_uniform,
            &ssao_noise_view,
            &csm_array_view, &csm_sampler,
            &cube_shadow_array_view, &cube_shadow_sampler,
            &camera_buffer, &lights_buffer, &ibl, 0.5, 1.0, &tonemap_uniform,
            &cluster_layout, &cluster_lighting_layout, &cluster_params_buffer,
        );

        let lens_flare_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("lens_flare_bg"),
            layout: &lens_flare_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&sd.hdr_fog_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&sd.linear_sampler) },
                wgpu::BindGroupEntry { binding: 2, resource: lens_flare_uniform.as_entire_binding() },
            ],
        });
        let dof_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("dof_bg"),
            layout: &dof_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&sd.hdr_fog_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&sd.gbuffer_normal_view) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&sd.linear_sampler) },
                wgpu::BindGroupEntry { binding: 3, resource: dof_uniform.as_entire_binding() },
            ],
        });
        let motion_blur_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("motion_blur_bg"),
            layout: &motion_blur_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&sd.hdr_dof_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&sd.motion_view) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&sd.linear_sampler) },
                wgpu::BindGroupEntry { binding: 3, resource: motion_blur_uniform.as_entire_binding() },
            ],
        });
        let decal_depth_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("decal_depth_bg"),
            layout: &decal_depth_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: wgpu::BindingResource::TextureView(&sd.gbuffer_depth_view),
            }],
        });
        let debug_depth_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("debug_depth_sampler"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Nearest,
            min_filter: wgpu::FilterMode::Nearest,
            ..Default::default()
        });
        let csm_debug_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("csm_debug_bg"),
            layout: &debug_depth_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&csm_array_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&debug_depth_sampler) },
            ],
        });

        let gpu_particles = gpu_particles::GpuParticleSystem::new(&device, &camera_layout);
        const INITIAL_INSTANCE_CAPACITY: u64 = 4096;
        let instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("instance_buffer"),
            size: INITIAL_INSTANCE_CAPACITY * std::mem::size_of::<InstanceData>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let fallback_texture = Texture::white(&device, &queue, &texture_layout).unwrap();
        let fallback_emissive = Texture::from_solid(&device, &queue, &texture_layout, [0, 0, 0, 255], "fallback_emissive").unwrap();
        let fallback_mr = Texture::from_solid_linear(&device, &queue, &texture_layout, [255, 255, 255, 255], "fallback_mr").unwrap();
        let fallback_normal = Texture::from_solid_linear(&device, &queue, &texture_layout, [128, 128, 255, 255], "fallback_normal").unwrap();

        let default_material = Material::default();
        let default_sampler_desc = SamplerDesc::default();
        let default_sampler = device.create_sampler(&default_sampler_desc.to_wgpu());
        let default_material_bind_group = build_object_bind_group(
            &device, &material_layout, &default_material,
            &fallback_texture, &fallback_mr, &fallback_normal, &fallback_emissive,
            &default_sampler, create_identity_skeleton_buffer(&device),
        );

        let line_buffer = LineBuffer::new(&device, 4096);

        const INITIAL_PARTICLES_CAPACITY: u64 = 2048;
        let particles_instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("particles_instance_buffer"),
            size: INITIAL_PARTICLES_CAPACITY * std::mem::size_of::<ParticleInstance>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        const INITIAL_DECAL_CAPACITY: u64 = 256;
        let decal_instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("decal_instance_buffer"),
            size: INITIAL_DECAL_CAPACITY * std::mem::size_of::<DecalInstance>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let ui_global_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("ui_global_buffer"),
            size: std::mem::size_of::<UiGlobal>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let font = Arc::new(crate::ui::font::Font::load_default());

        let ui_font_atlas_tex = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("ui_font_atlas"),
            size: wgpu::Extent3d {
                width: font.atlas_w,
                height: font.atlas_h,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1, sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8UnormSrgb,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });
        queue.write_texture(
            wgpu::TexelCopyTextureInfo {
                texture: &ui_font_atlas_tex, mip_level: 0,
                origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All,
            },
            &font.atlas,
            wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(font.atlas_w * 4),
                rows_per_image: Some(font.atlas_h),
            },
            wgpu::Extent3d {
                width: font.atlas_w,
                height: font.atlas_h,
                depth_or_array_layers: 1,
            },
        );
        let ui_font_atlas_view = ui_font_atlas_tex.create_view(&wgpu::TextureViewDescriptor::default());
        let ui_font_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("ui_font_sampler"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            ..Default::default()
        });

        let ui_global_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("ui_global_bind_group"),
            layout: &ui_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: ui_global_buffer.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&ui_font_atlas_view) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&ui_font_sampler) },
            ],
        });

        let ui_shader_src = crate::shader_source!("src/render/shaders/ui.wgsl").expect("ui.wgsl not found");
        let ui_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("ui_shader"),
            source: wgpu::ShaderSource::Wgsl(ui_shader_src.into()),
        });

        let ui_pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("ui_pipeline_layout"),
            bind_group_layouts: &[Some(&ui_layout)],
            immediate_size: 0,
        });

        let ui_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("ui_pipeline"),
            layout: Some(&ui_pipeline_layout),
            vertex: wgpu::VertexState {
                module: &ui_shader, entry_point: Some("vs_main"),
                buffers: &[Some(UiQuad::layout())],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &ui_shader, entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format: config.format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })], compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                front_face: wgpu::FrontFace::Ccw,
                cull_mode: None, ..Default::default()
            },
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            multiview_mask: None, cache: None,
        });

        const INITIAL_UI_CAPACITY: u64 = 1024;
        let ui_instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("ui_instance_buffer"),
            size: INITIAL_UI_CAPACITY * std::mem::size_of::<UiQuad>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        Self {
            surface, device, queue, config, size,
            camera_layout, lights_layout, shadow_pass_layout, shadow2_layout,
            contact_shadow_layout, contact_shadow_uniform, contact_shadow_pipeline,
            texture_layout, material_layout, ssao_layout, lighting_layout,
            bloom_layout, tonemap_layout, debug_layout, debug_depth_layout, skybox_layout,
            taa_layout, lens_flare_layout, dof_layout, motion_blur_layout,
            cluster_layout, cluster_lighting_layout, cluster_pipeline, cluster_params_buffer,
            atmosphere_layout, atmosphere_pipeline, atmosphere_uniform, atmosphere_bind_group,
            atmosphere_settings: atmosphere::AtmosphereSettings::default(),

            // === Sprint 8: reflection probes ===
            probes,
            probe_bake_pipeline,
            probe_bake_uniform,
            probe_bake_layout,
            probe_bake_bind_group,
            probe_bake_depth_view,
            _probe_bake_depth_tex: probe_bake_depth_tex,
            probe_bake_motion_view,
            _probe_bake_motion_tex: probe_bake_motion_tex,
            probe_lighting_layout,
            probe_lighting_uniform,
            probe_lighting_bind_group,

            volumetric_compute_layout, volumetric_composite_layout,
            volumetric_uniform, volumetric_pipeline, volumetric_composite_pipeline,
            camera_buffer, camera_bind_group,
            lights_buffer, lights_bind_group,
            shadow_pass_buffer, shadow_pass_bind_group, shadow_pass_stride,
            csm_array_view, csm_cascade_views, csm_sampler,
            cube_shadow_array_view, cube_shadow_face_views, cube_shadow_sampler,
            material_bind_groups: HashMap::new(),
            default_material_bind_group,
            sampler_cache: HashMap::new(),
            skeleton_buffers: HashMap::new(),
            fallback_texture, fallback_mr, fallback_normal, fallback_emissive,
            gbuffer_pipeline, gbuffer_pipeline_double_sided,
            shadow_pipeline, shadow_pipeline_double_sided,
            line_pipeline, particles_pipeline,
            transparent_pipeline, transparent_pipeline_double_sided,
            lighting_pipeline, ssao_pipeline, ssao_blur_pipeline,
            bloom_prefilter_pipeline, bloom_downsample_pipeline, bloom_upsample_pipeline,
            tonemap_pipeline, fxaa_pipeline, skybox_pipeline, taa_pipeline, decal_pipeline,
            debug2d_pipeline, debug_depth_pipeline, csm_debug_bind_group,
            tonemap_uniform, ssao_uniform, skybox_uniform, skybox_bind_group,
            lens_flare_uniform, lens_flare_pipeline, lens_flare_bind_group,
            dof_uniform, dof_pipeline, dof_bind_group,
            motion_blur_uniform, motion_blur_pipeline, motion_blur_bind_group,
            _ssao_noise_tex: ssao_noise_tex, ssao_noise_view,
            ibl: Some(ibl), sd,
            instance_buffer, instance_capacity: INITIAL_INSTANCE_CAPACITY,
            line_buffer,
            particles_instance_buffer, particles_instance_capacity: INITIAL_PARTICLES_CAPACITY,
            decal_texture_layout, decal_depth_layout, decal_depth_bind_group,
            decal_texture_bind_groups: HashMap::new(),
            decal_instance_buffer, decal_instance_capacity: INITIAL_DECAL_CAPACITY,
            meshes: HashMap::new(),
            materials: MaterialRegistry::new(),
            textures: HashMap::new(),
            default_material, terrain: None,
            skybox_time: 0.0,
            taa_frame_index: 0,
            taa_prev_view_proj: Mat4::IDENTITY,
            taa_reset_frames: 2,
            taa_prev_camera_mode: None,
            taa_prev_jitter_px: Vec2::ZERO,
            taa_prev_enabled: true,
            gpu_particles,
            last_render_time: 0.0,
            last_draw_count: 0, last_instance_count: 0,
            features,
            render_scale: initial_render_scale,
            ui_pipeline, ui_global_buffer, ui_global_bind_group,
            ui_instance_buffer, ui_instance_capacity: INITIAL_UI_CAPACITY,
            _ui_font_atlas_tex: ui_font_atlas_tex,
            font,
        }
    }

    fn ensure_ui_capacity(&mut self, needed: u64) {
        if needed <= self.ui_instance_capacity { return; }
        let new_cap = (self.ui_instance_capacity * 2).max(needed);
        self.ui_instance_buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("ui_instance_buffer"),
            size: new_cap * std::mem::size_of::<UiQuad>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        self.ui_instance_capacity = new_cap;
    }

    #[cfg(debug_assertions)]
    pub fn reload_shaders(&mut self) -> Result<(), String> {
        let error_scope = self.device.push_error_scope(wgpu::ErrorFilter::Validation);

        let build = || -> Result<BuiltPipelines, String> {
            Ok(BuiltPipelines {
                gbuffer: make_gbuffer_pipeline(&self.device, &self.camera_layout, &self.material_layout, Some(wgpu::Face::Back))?,
                gbuffer_double_sided: make_gbuffer_pipeline(&self.device, &self.camera_layout, &self.material_layout, None)?,
                shadow: make_shadow_pipeline(&self.device, &self.shadow_pass_layout, &self.material_layout, Some(wgpu::Face::Back))?,
                shadow_double_sided: make_shadow_pipeline(&self.device, &self.shadow_pass_layout, &self.material_layout, None)?,
                line: make_line_pipeline(&self.device, &self.camera_layout)?,
                particles: make_particles_pipeline(&self.device, &self.camera_layout)?,
                transparent: make_transparent_pipeline(&self.device, &self.camera_layout, &self.lights_layout, &self.shadow2_layout, &self.material_layout, Some(wgpu::Face::Back))?,
                transparent_double_sided: make_transparent_pipeline(&self.device, &self.camera_layout, &self.lights_layout, &self.shadow2_layout, &self.material_layout, None)?,
                // FIX: `make_lighting_pipeline` теперь принимает
                // 6-й аргумент — `probe_lighting_layout` (группа 4).
                lighting: make_lighting_pipeline(
                    &self.device,
                    &self.lighting_layout,
                    &self.lights_layout,
                    &self.shadow2_layout,
                    &self.cluster_lighting_layout,
                    &self.probe_lighting_layout,
                )?,
                ssao: make_ssao_pipelines(&self.device, &self.ssao_layout)?,
                bloom_chain: make_bloom_chain_pipelines(&self.device, &self.bloom_layout)?,
                tonemap: make_tonemap_pipeline(&self.device, &self.config, &self.tonemap_layout)?,
                debug: make_debug_pipelines(&self.device, &self.config, &self.debug_layout, &self.debug_depth_layout)?,
                fxaa: make_fxaa_pipeline(&self.device, &self.config, &self.debug_layout)?,
                skybox: make_skybox_pipeline(&self.device, &self.skybox_layout)?,
                atmosphere: {
                    let src = crate::shader_source!("src/render/shaders/sky_atmosphere.wgsl")?;
                    let shader = self.device.create_shader_module(wgpu::ShaderModuleDescriptor {
                        label: Some("atmosphere_shader"),
                        source: wgpu::ShaderSource::Wgsl(src.into()),
                    });
                    let layout = self.device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                        label: Some("atmosphere_pipeline_layout"),
                        bind_group_layouts: &[Some(&self.atmosphere_layout)],
                        immediate_size: 0,
                    });
                    self.device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                        label: Some("atmosphere_pipeline"),
                        layout: Some(&layout),
                        vertex: wgpu::VertexState {
                            module: &shader, entry_point: Some("vs_main"),
                            buffers: &[], compilation_options: Default::default(),
                        },
                        fragment: Some(wgpu::FragmentState {
                            module: &shader, entry_point: Some("fs_main"),
                            targets: &[Some(wgpu::ColorTargetState {
                                format: HDR_FORMAT, blend: None,
                                write_mask: wgpu::ColorWrites::ALL,
                            })], compilation_options: Default::default(),
                        }),
                        primitive: wgpu::PrimitiveState::default(),
                        depth_stencil: Some(wgpu::DepthStencilState {
                            format: DEPTH_FORMAT,
                            // Небо не пишет в depth — иначе перекроет всё
                            // (fullscreen triangle, fragment.z = 0).
                            depth_write_enabled: Some(false),
                            // Должно совпадать с Renderer::new (LessEqual).
                            // Раньше было `Always` → после F12 небо рисовалось
                            // поверх всей сцены.
                            depth_compare: Some(wgpu::CompareFunction::LessEqual),
                            stencil: wgpu::StencilState::default(),
                            bias: wgpu::DepthBiasState::default(),
                        }),
                        multisample: wgpu::MultisampleState::default(),
                        multiview_mask: None, cache: None,
                    })
                },
                taa: make_taa_pipeline(&self.device, &self.taa_layout)?,
                decal: make_decal_pipeline(&self.device, &self.camera_layout, &self.decal_texture_layout, &self.decal_depth_layout)?,
                lens_flare: make_lens_flare_pipeline(&self.device, &self.lens_flare_layout, HDR_FORMAT)?,
                dof: make_dof_pipeline(&self.device, &self.dof_layout, HDR_FORMAT)?,
                motion_blur: make_motion_blur_pipeline(&self.device, &self.motion_blur_layout, HDR_FORMAT)?,
                volumetric_composite: {
                    let src = crate::shader_source!("src/render/shaders/volumetric_composite.wgsl")?;
                    let shader = self.device.create_shader_module(wgpu::ShaderModuleDescriptor {
                        label: Some("volumetric_composite_shader"),
                        source: wgpu::ShaderSource::Wgsl(src.into()),
                    });
                    let layout = self.device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                        label: Some("volumetric_composite_pipeline_layout"),
                        bind_group_layouts: &[Some(&self.volumetric_composite_layout)],
                        immediate_size: 0,
                    });
                    self.device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                        label: Some("volumetric_composite_pipeline"),
                        layout: Some(&layout),
                        vertex: wgpu::VertexState {
                            module: &shader, entry_point: Some("vs_main"),
                            buffers: &[], compilation_options: Default::default(),
                        },
                        fragment: Some(wgpu::FragmentState {
                            module: &shader, entry_point: Some("fs_main"),
                            targets: &[Some(wgpu::ColorTargetState {
                                format: HDR_FORMAT,
                                blend: Some(wgpu::BlendState::REPLACE),
                                write_mask: wgpu::ColorWrites::ALL,
                            })], compilation_options: Default::default(),
                        }),
                        primitive: wgpu::PrimitiveState::default(),
                        depth_stencil: None,
                        multisample: wgpu::MultisampleState::default(),
                        multiview_mask: None, cache: None,
                    })
                },
            })
        };

        let built = match build() {
            Ok(b) => {
                if let Some(err) = pollster::block_on(error_scope.pop()) {
                    return Err(format!("{}", err));
                }
                b
            }
            Err(msg) => { let _ = pollster::block_on(error_scope.pop()); return Err(msg); }
        };

        self.gbuffer_pipeline = built.gbuffer;
        self.gbuffer_pipeline_double_sided = built.gbuffer_double_sided;
        self.shadow_pipeline = built.shadow;
        self.shadow_pipeline_double_sided = built.shadow_double_sided;
        self.line_pipeline = built.line;
        self.particles_pipeline = built.particles;
        self.transparent_pipeline = built.transparent;
        self.transparent_pipeline_double_sided = built.transparent_double_sided;
        self.lighting_pipeline = built.lighting;
        self.ssao_pipeline = built.ssao.0;
        self.ssao_blur_pipeline = built.ssao.1;
        self.bloom_prefilter_pipeline = built.bloom_chain.0;
        self.bloom_downsample_pipeline = built.bloom_chain.1;
        self.bloom_upsample_pipeline = built.bloom_chain.2;
        self.tonemap_pipeline = built.tonemap;
        self.debug2d_pipeline = built.debug.0;
        self.debug_depth_pipeline = built.debug.1;
        self.fxaa_pipeline = built.fxaa;
        self.skybox_pipeline = built.skybox;
        self.atmosphere_pipeline = built.atmosphere;
        self.taa_pipeline = built.taa;
        self.decal_pipeline = built.decal;
        self.lens_flare_pipeline = built.lens_flare;
        self.dof_pipeline = built.dof;
        self.motion_blur_pipeline = built.motion_blur;
        self.volumetric_composite_pipeline = built.volumetric_composite;
        Ok(())
    }

    #[cfg(not(debug_assertions))]
    pub fn reload_shaders(&mut self) -> Result<(), String> {
        Err("hot-reload is only supported in debug builds".into())
    }

    pub fn add_mesh(&mut self, name: impl Into<String>, mesh: Mesh) {
        let name = name.into();
        for (i, lod) in mesh.lods.iter().enumerate() {
            let lod_mesh = Mesh::from_raw_parts(
                &self.device, &lod.vertices, &lod.indices,
                &format!("{}__lod{}", name, i), false,
            );
            self.meshes.insert(format!("{}__lod{}", name, i), lod_mesh);
        }
        self.meshes.insert(name, mesh);
    }

    pub fn mesh_names(&self) -> Vec<String> {
        let mut v: Vec<String> = self.meshes.keys().filter(|k| !k.contains("__lod")).cloned().collect();
        v.sort(); v
    }

    pub fn material_names(&self) -> Vec<String> { self.materials.names() }

    pub fn texture_names(&self) -> Vec<String> {
        let mut v: Vec<String> = self.textures.keys().cloned().collect();
        v.sort(); v
    }

    pub fn texture_size(&self, name: &str) -> Option<(u32, u32)> {
        self.textures.get(name).map(|t| t.size)
    }

    pub fn texture_source_path(&self, name: &str) -> Option<&str> {
        self.textures.get(name)?.source_path.as_deref()
    }

    pub fn remove_texture(&mut self, name: &str) -> bool {
        self.decal_texture_bind_groups.remove(name);
        self.textures.remove(name).is_some()
    }

    pub fn load_texture_rgba(&mut self, name: &str, data: &[u8], width: u32, height: u32) -> anyhow::Result<()> {
        let tex = Texture::from_rgba(&self.device, &self.queue, &self.texture_layout, data, width, height, name)?;
        self.textures.insert(name.to_string(), tex);
        Ok(())
    }

    pub fn load_texture_rgba_linear(&mut self, name: &str, data: &[u8], width: u32, height: u32) -> anyhow::Result<()> {
        let tex = Texture::from_rgba_linear(&self.device, &self.queue, &self.texture_layout, data, width, height, name)?;
        self.textures.insert(name.to_string(), tex);
        Ok(())
    }

    pub fn load_texture(&mut self, name: &str, path: &str) -> anyhow::Result<()> {
        let tex = Texture::from_file(&self.device, &self.queue, &self.texture_layout, path)?;
        self.textures.insert(name.to_string(), tex);
        Ok(())
    }

    pub fn load_texture_linear(&mut self, name: &str, path: &str) -> anyhow::Result<()> {
        let tex = Texture::from_file_linear(&self.device, &self.queue, &self.texture_layout, path)?;
        self.textures.insert(name.to_string(), tex);
        Ok(())
    }

    pub fn load_texture_bytes(&mut self, name: &str, bytes: &[u8]) -> anyhow::Result<()> {
        let tex = Texture::from_bytes(&self.device, &self.queue, &self.texture_layout, bytes, name)?;
        self.textures.insert(name.to_string(), tex);
        Ok(())
    }

    pub fn ensure_decal_bg(&mut self, name: &str) {
        if self.decal_texture_bind_groups.contains_key(name) { return; }

        // FIX (P0.5): "white" — это fallback_texture, не запись в `textures`.
        // Без фолбэка Decal::default() (texture = "white") не рендерился.
        if name == "white" {
            let bg = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: Some("decal_white_bg"),
                layout: &self.decal_texture_layout,
                entries: &[
                    wgpu::BindGroupEntry {
                        binding: 0,
                        resource: wgpu::BindingResource::TextureView(&self.fallback_texture.view),
                    },
                    wgpu::BindGroupEntry {
                        binding: 1,
                        resource: wgpu::BindingResource::Sampler(&self.fallback_texture.sampler),
                    },
                ],
            });
            self.decal_texture_bind_groups.insert("white".to_string(), bg);
            return;
        }

        let Some(tex) = self.textures.remove(name) else { return; };
        let bg = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("decal_texture_bg"),
            layout: &self.decal_texture_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&tex.view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&tex.sampler) },
            ],
        });
        self.textures.insert(name.to_string(), tex);
        self.decal_texture_bind_groups.insert(name.to_string(), bg);
    }

    fn ensure_decal_capacity(&mut self, needed: u64) {
        if needed <= self.decal_instance_capacity { return; }
        let new_cap = (self.decal_instance_capacity * 2).max(needed);
        self.decal_instance_buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("decal_instance_buffer"),
            size: new_cap * std::mem::size_of::<DecalInstance>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        self.decal_instance_capacity = new_cap;
    }

    fn get_sampler(&mut self, desc: &SamplerDesc) -> Arc<wgpu::Sampler> {
        if let Some(s) = self.sampler_cache.get(desc) { return Arc::clone(s); }
        let s = Arc::new(self.device.create_sampler(&desc.to_wgpu()));
        self.sampler_cache.insert(*desc, Arc::clone(&s));
        s
    }

    pub fn add_material(&mut self, name: impl Into<String>, mat: Material) {
        let name = name.into();
        let sampler = self.get_sampler(&mat.sampler);
        let base_tex = mat.base_color_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_texture);
        let mr_tex = mat.metallic_roughness_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_mr);
        let normal_tex = mat.normal_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_normal);
        let emissive_tex = mat.emissive_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_emissive);
        let gpu = build_object_bind_group(
            &self.device, &self.material_layout, &mat,
            base_tex, mr_tex, normal_tex, emissive_tex,
            &sampler, create_identity_skeleton_buffer(&self.device),
        );
        self.materials.insert(name.clone(), mat);
        self.material_bind_groups.insert(name, gpu);
    }

    pub fn has_material(&self, name: &str) -> bool {
        self.material_bind_groups.contains_key(name)
    }

    pub fn add_material_with_skeleton(&mut self, name: &str, mat: Material, skeleton_name: &str) {
        let sampler = self.get_sampler(&mat.sampler);
        let base_tex = mat.base_color_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_texture);
        let mr_tex = mat.metallic_roughness_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_mr);
        let normal_tex = mat.normal_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_normal);
        let emissive_tex = mat.emissive_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_emissive);
        let skeleton_uniform = self.skeleton_buffers.get(skeleton_name).cloned()
            .unwrap_or_else(|| create_identity_skeleton_buffer(&self.device));
        let gpu = build_object_bind_group(
            &self.device, &self.material_layout, &mat,
            base_tex, mr_tex, normal_tex, emissive_tex, &sampler, skeleton_uniform,
        );
        self.materials.insert(name.to_string(), mat);
        self.material_bind_groups.insert(name.to_string(), gpu);
    }

    pub fn update_material(&mut self, name: &str, mat: Material) {
        if self.materials.get(name).is_none() { return; }
        let sampler = self.get_sampler(&mat.sampler);
        let base_tex = mat.base_color_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_texture);
        let mr_tex = mat.metallic_roughness_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_mr);
        let normal_tex = mat.normal_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_normal);
        let emissive_tex = mat.emissive_texture.as_deref().and_then(|n| self.textures.get(n)).unwrap_or(&self.fallback_emissive);
        let skeleton_uniform = self.material_bind_groups.get(name).map(|g| g.skeleton_uniform.clone())
            .unwrap_or_else(|| create_identity_skeleton_buffer(&self.device));
        let gpu = build_object_bind_group(
            &self.device, &self.material_layout, &mat,
            base_tex, mr_tex, normal_tex, emissive_tex, &sampler, skeleton_uniform,
        );
        self.materials.insert(name.to_string(), mat);
        self.material_bind_groups.insert(name.to_string(), gpu);
    }

    pub fn materials_default(&self) -> &Material { &self.default_material }

    pub fn add_skeleton(&mut self, name: impl Into<String>, matrices: &[Mat4]) {
        let name = name.into();
        let data = if matrices.is_empty() { SkeletonUniform::identity() }
                   else { SkeletonUniform::from_matrices(matrices) };
        let buffer = Arc::new(self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("skeleton_buffer"),
            size: std::mem::size_of::<SkeletonUniform>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        }));
        self.queue.write_buffer(&buffer, 0, bytemuck::bytes_of(&data));
        self.skeleton_buffers.insert(name, buffer);
    }

    pub fn update_skeleton(&mut self, name: &str, matrices: &[Mat4]) {
        let Some(buffer) = self.skeleton_buffers.get(name) else { return; };
        let data = if matrices.is_empty() { SkeletonUniform::identity() }
                   else { SkeletonUniform::from_matrices(matrices) };
        self.queue.write_buffer(buffer, 0, bytemuck::bytes_of(&data));
    }

    pub fn resize(&mut self, new_size: winit::dpi::PhysicalSize<u32>) {
        if new_size.width == 0 || new_size.height == 0 { return; }
        self.size = new_size;
        self.config.width = new_size.width;
        self.config.height = new_size.height;
        self.surface.configure(&self.device, &self.config);

        let ibl_ref = self.ibl.as_ref().expect("IBL must be initialized");

        let mut internal_config = self.config.clone();
        let (iw, ih) = self.internal_size();
        internal_config.width = iw;
        internal_config.height = ih;

        self.sd = build_size_dependent(
            &self.device, &internal_config,
            &self.bloom_layout, &self.tonemap_layout, &self.ssao_layout,
            &self.shadow2_layout, &self.debug_layout, &self.lighting_layout,
            &self.taa_layout,
            &self.volumetric_compute_layout, &self.volumetric_composite_layout,
            &self.contact_shadow_layout,
            &self.ssao_uniform, &self.volumetric_uniform,
            &self.contact_shadow_uniform,
            &self.ssao_noise_view,
            &self.csm_array_view, &self.csm_sampler,
            &self.cube_shadow_array_view, &self.cube_shadow_sampler,
            &self.camera_buffer, &self.lights_buffer, ibl_ref, 0.5, 1.0,
            &self.tonemap_uniform,
            &self.cluster_layout, &self.cluster_lighting_layout, &self.cluster_params_buffer,
        );
        self.rebuild_after_size_change();
    }

    fn internal_size(&self) -> (u32, u32) {
        let scale = self.render_scale.clamp(0.5, 2.0);
        (
            ((self.config.width as f32) * scale).round().max(1.0) as u32,
            ((self.config.height as f32) * scale).round().max(1.0) as u32,
        )
    }

    fn rebuild_after_size_change(&mut self) {
        self.lens_flare_bind_group = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("lens_flare_bg"),
            layout: &self.lens_flare_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&self.sd.hdr_fog_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&self.sd.linear_sampler) },
                wgpu::BindGroupEntry { binding: 2, resource: self.lens_flare_uniform.as_entire_binding() },
            ],
        });
        self.dof_bind_group = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("dof_bg"),
            layout: &self.dof_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&self.sd.hdr_fog_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&self.sd.gbuffer_normal_view) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&self.sd.linear_sampler) },
                wgpu::BindGroupEntry { binding: 3, resource: self.dof_uniform.as_entire_binding() },
            ],
        });
        self.motion_blur_bind_group = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("motion_blur_bg"),
            layout: &self.motion_blur_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&self.sd.hdr_dof_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&self.sd.motion_view) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&self.sd.linear_sampler) },
                wgpu::BindGroupEntry { binding: 3, resource: self.motion_blur_uniform.as_entire_binding() },
            ],
        });
        self.decal_depth_bind_group = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("decal_depth_bg"),
            layout: &self.decal_depth_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: wgpu::BindingResource::TextureView(&self.sd.gbuffer_depth_view),
            }],
        });
        let debug_depth_sampler = self.device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("debug_depth_sampler"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Nearest,
            min_filter: wgpu::FilterMode::Nearest,
            ..Default::default()
        });
        self.csm_debug_bind_group = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("csm_debug_bg"),
            layout: &self.debug_depth_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&self.csm_array_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&debug_depth_sampler) },
            ],
        });
        self.taa_reset_frames = 2;
    }

    pub fn set_render_scale(&mut self, scale: f32) {
        let s = scale.clamp(0.5, 2.0);
        if (s - self.render_scale).abs() < 0.001 { return; }
        self.render_scale = s;
        log::info!("Renderer: render_scale = {:.2} ({:.0}% internal)", s, s * 100.0);

        let ibl_ref = self.ibl.as_ref().expect("IBL must be initialized");
        let mut internal_config = self.config.clone();
        let (iw, ih) = self.internal_size();
        internal_config.width = iw;
        internal_config.height = ih;

        self.sd = build_size_dependent(
            &self.device, &internal_config,
            &self.bloom_layout, &self.tonemap_layout, &self.ssao_layout,
            &self.shadow2_layout, &self.debug_layout, &self.lighting_layout,
            &self.taa_layout,
            &self.volumetric_compute_layout, &self.volumetric_composite_layout,
            &self.contact_shadow_layout,
            &self.ssao_uniform, &self.volumetric_uniform,
            &self.contact_shadow_uniform,
            &self.ssao_noise_view,
            &self.csm_array_view, &self.csm_sampler,
            &self.cube_shadow_array_view, &self.cube_shadow_sampler,
            &self.camera_buffer, &self.lights_buffer, ibl_ref, 0.5, 1.0,
            &self.tonemap_uniform,
            &self.cluster_layout, &self.cluster_lighting_layout, &self.cluster_params_buffer,
        );
        self.rebuild_after_size_change();
    }

    pub fn set_present_mode(&mut self, mode: wgpu::PresentMode) {
        if self.config.present_mode != mode {
            self.config.present_mode = mode;
            self.surface.configure(&self.device, &self.config);
            log::info!("Renderer: present mode → {:?}", mode);
        }
    }

    pub(crate) fn ensure_instance_capacity(&mut self, needed: u64) {
        if needed <= self.instance_capacity { return; }
        let new_cap = (self.instance_capacity * 2).max(needed);
        self.instance_buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("instance_buffer"),
            size: new_cap * std::mem::size_of::<InstanceData>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        self.instance_capacity = new_cap;
    }

    fn ensure_particles_capacity(&mut self, needed: u64) {
        if needed <= self.particles_instance_capacity { return; }
        let new_cap = (self.particles_instance_capacity * 2).max(needed);
        self.particles_instance_buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("particles_instance_buffer"),
            size: new_cap * std::mem::size_of::<ParticleInstance>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        self.particles_instance_capacity = new_cap;
    }

    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        camera: &Camera3D,
        draws: &[MeshDraw],
        decals: &[DecalDraw],
        particle_instances: &[ParticleInstance],
        line_vertices: &[LineVertex],
        dir_lights: &[GpuLight],
        point_lights: &[GpuPointLight],
        ambient: [f32; 3],
        postfx: PostFx,
        time: f32,
        ui_quads: &[UiQuad],
        egui_data: Option<EguiFrameData<'_>>,
    ) -> Result<(), String> {
        self.skybox_time = time;
        let (iw, ih) = self.internal_size();
        let w_px = iw.max(1) as f32;
        let h_px = ih.max(1) as f32;
        let surface_w = self.config.width.max(1) as f32;
        let surface_h = self.config.height.max(1) as f32;

        if self.taa_prev_camera_mode != Some(camera.mode) {
            self.taa_reset_frames = 2;
            self.taa_prev_camera_mode = Some(camera.mode);
        }

        let use_taa = postfx.taa_strength > 0.01;
        if use_taa != self.taa_prev_enabled {
            self.taa_reset_frames = 2;
            self.taa_prev_enabled = use_taa;
        }

        const HALTON_X: [f32; 8] = [0.500, 0.250, 0.750, 0.125, 0.625, 0.375, 0.875, 0.0625];
        const HALTON_Y: [f32; 8] = [0.333, 0.667, 0.111, 0.444, 0.778, 0.222, 0.556, 0.889];
        let halton_idx = (self.taa_frame_index as usize) % 8;
        let jitter_pixels = Vec2::new(HALTON_X[halton_idx] - 0.5, HALTON_Y[halton_idx] - 0.5);
        let jitter_ndc = Vec2::new(jitter_pixels.x * 2.0 / w_px, jitter_pixels.y * 2.0 / h_px);

        let view = camera.view_matrix();
        let proj_unjittered = camera.proj_matrix();
        let mut proj_jittered = proj_unjittered;
        proj_jittered.z_axis.x -= jitter_ndc.x;
        proj_jittered.z_axis.y -= jitter_ndc.y;
        let vp_jittered = proj_jittered * view;
        let vp_unjittered = proj_unjittered * view;

        let camera_uniform = CameraUniform {
            view_proj: vp_jittered.to_cols_array_2d(),
            inv_view_proj: vp_jittered.inverse().to_cols_array_2d(),
            view: view.to_cols_array_2d(),
            inv_view: view.inverse().to_cols_array_2d(),
            camera_pos: camera.position().extend(1.0).to_array(),
            near_far: [camera.near, camera.far, jitter_pixels.x, jitter_pixels.y],
            prev_view_proj: self.taa_prev_view_proj.to_cols_array_2d(),
            screen_size: [w_px, h_px, 1.0 / w_px, 1.0 / h_px],
        };
        self.queue.write_buffer(&self.camera_buffer, 0, bytemuck::bytes_of(&camera_uniform));
        self.taa_prev_view_proj = vp_unjittered;

        let write_idx = (self.taa_frame_index as usize) & 1;
        let reset_flag = if self.taa_reset_frames > 0 { 1.0 } else { 0.0 };
        if self.taa_reset_frames > 0 { self.taa_reset_frames -= 1; }

        let taa_params = TaaParams {
            values: [
                (1.0 - postfx.taa_strength) + postfx.taa_strength * 0.1,
                0.125, postfx.taa_sharpening, reset_flag,
            ],
            screen: [w_px, h_px, jitter_pixels.x, jitter_pixels.y],
            prev_jitter: [self.taa_prev_jitter_px.x, self.taa_prev_jitter_px.y, 0.0, 0.0],
        };
        self.queue.write_buffer(&self.sd.taa_uniform, 0, bytemuck::bytes_of(&taa_params));
        self.taa_prev_jitter_px = jitter_pixels;

        if use_taa {
            self.taa_frame_index = self.taa_frame_index.wrapping_add(1);
        }

        let dir_light_dir = dir_lights.first()
            .map(|l| Vec3::new(l.direction[0], l.direction[1], l.direction[2]))
            .unwrap_or(Vec3::Y);

        let mut dir_packed = [[0.0f32; 4]; 16];
        let dir_count = dir_lights.len().min(MAX_DIR_LIGHTS);
        for i in 0..dir_count {
            dir_packed[i * 2] = dir_lights[i].direction;
            dir_packed[i * 2 + 1] = dir_lights[i].color;
        }
        let mut pt_packed = [[0.0f32; 4]; 64];
        let pt_count = point_lights.len().min(MAX_POINT_LIGHTS);
        for i in 0..pt_count {
            pt_packed[i * 2] = point_lights[i].position;
            pt_packed[i * 2 + 1] = point_lights[i].color;
        }

        let shadow_point_count = pt_count.min(MAX_SHADOW_CUBES);
        let mut cube_pos_packed = [[0.0f32; 4]; 4];
        for i in 0..shadow_point_count {
            cube_pos_packed[i] = point_lights[i].position;
        }

        let clustered_light_count = point_lights.len().min(MAX_POINT_LIGHTS_CLUSTERED);
        if clustered_light_count > 0 {
            let bytes: &[u8] = bytemuck::cast_slice(&point_lights[..clustered_light_count]);
            self.queue.write_buffer(&self.sd.point_lights_storage_buffer, 0, bytes);
        }

        let cluster_grid_x = (w_px as u32 + CLUSTER_TILE_SIZE - 1) / CLUSTER_TILE_SIZE;
        let cluster_grid_y = (h_px as u32 + CLUSTER_TILE_SIZE - 1) / CLUSTER_TILE_SIZE;
        let cluster_grid_z = CLUSTER_GRID_Z;
        let cluster_params = ClusterParams {
            grid: [
                cluster_grid_x as f32,
                cluster_grid_y as f32,
                cluster_grid_z as f32,
                clustered_light_count as f32,
            ],
            screen: [w_px, h_px, 1.0 / w_px, 1.0 / h_px],
            near_far: [camera.near, camera.far, 1.0 / camera.far.max(1e-4), 0.0],
            proj: proj_unjittered.to_cols_array_2d(),
            view: view.to_cols_array_2d(),
        };
        self.queue.write_buffer(&self.cluster_params_buffer, 0, bytemuck::bytes_of(&cluster_params));

        // FIX: обновить per-probe uniform (group 4). Иначе `counts.x = 0`
        // и шейдер всегда фолбэкается на глобальный IBL, не показывая
        // отражения в помещениях.
        probe::update_lighting_uniform(
            &self.queue,
            &self.probe_lighting_uniform,
            &self.probes,
        );

        let splits = csm::split_distances(camera.near, camera.far.min(200.0), 0.5);
        let cascade_vp = csm::build_cascades(view, proj_unjittered, camera.near, camera.far, dir_light_dir, &splits);
        let mut csm_packed = [[[0.0f32; 4]; 4]; CASCADE_COUNT];
        for i in 0..CASCADE_COUNT { csm_packed[i] = cascade_vp[i].to_cols_array_2d(); }

        let ambient_color = [ambient[0], ambient[1], ambient[2], 1.0];
        let misc = [postfx.ibl_strength, 0.0, 0.0, 0.0];
        let fog_params = [postfx.fog_density, postfx.fog_height_base, postfx.fog_height_falloff, 0.0];
        let fog_color = [postfx.fog_color[0], postfx.fog_color[1], postfx.fog_color[2], 0.0];
        let shadow_params = [
            postfx.shadow_bias, postfx.shadow_normal_bias,
            postfx.shadow_fade_start, postfx.shadow_fade_end,
        ];

        let lights_uniform = LightsUniform {
            cascade_vp: csm_packed,
            cascade_splits: [splits[1], splits[2], splits[3], 0.0],
            ambient_color,
            counts: [dir_count as u32, pt_count as u32, shadow_point_count as u32, 0],
            light_view_proj: cascade_vp[0].to_cols_array_2d(),
            misc, fog_params, fog_color, shadow_params,
            dir_lights: dir_packed,
            point_lights: pt_packed,
            cube_shadow_pos: cube_pos_packed,
        };
        self.queue.write_buffer(&self.lights_buffer, 0, bytemuck::bytes_of(&lights_uniform));

        {
            let stride = self.shadow_pass_stride as usize;
            let light_size = std::mem::size_of::<LightsUniform>();
            let mut bytes = vec![0u8; stride * SHADOW_SLOT_COUNT as usize];

            let write_slot = |bytes: &mut Vec<u8>, slot: usize, mat: Mat4| {
                let u = LightsUniform {
                    cascade_vp: csm_packed,
                    cascade_splits: [splits[1], splits[2], splits[3], 0.0],
                    ambient_color,
                    counts: [dir_count as u32, pt_count as u32, shadow_point_count as u32, 0],
                    light_view_proj: mat.to_cols_array_2d(),
                    misc, fog_params, fog_color, shadow_params,
                    dir_lights: dir_packed,
                    point_lights: pt_packed,
                    cube_shadow_pos: cube_pos_packed,
                };
                let src = bytemuck::bytes_of(&u);
                let off = slot * stride;
                bytes[off..off + light_size].copy_from_slice(src);
            };

            for c in 0..CASCADE_COUNT { write_slot(&mut bytes, c, cascade_vp[c]); }
            for cube in 0..shadow_point_count {
                let light_pos = Vec3::new(
                    point_lights[cube].position[0],
                    point_lights[cube].position[1],
                    point_lights[cube].position[2],
                );
                let range = point_lights[cube].position[3];
                let faces = shadow_cube::cube_face_matrices(light_pos, range);
                for (face, m) in faces.iter().enumerate() {
                    write_slot(&mut bytes, 3 + cube * 6 + face, *m);
                }
            }
            for cube in shadow_point_count..MAX_SHADOW_CUBES {
                for face in 0..6 {
                    write_slot(&mut bytes, 3 + cube * 6 + face, Mat4::IDENTITY);
                }
            }
            self.queue.write_buffer(&self.shadow_pass_buffer, 0, &bytes);
        }

        self.sd.bloom_chain.update_params(&self.queue, postfx.bloom_threshold, postfx.bloom_knee, postfx.bloom_radius);

        let tonemap_params = TonemapParams {
            values: [postfx.bloom_strength, postfx.exposure, self.skybox_time, 0.0],
            effects: [postfx.vignette_strength, postfx.film_grain, postfx.chromatic_aberration, 0.0],
            grading_a: [postfx.color_temperature, postfx.color_tint, postfx.color_contrast, postfx.color_saturation],
            grading_b: [postfx.exposure_bias, postfx.tonemapper as u32 as f32, 0.0, 0.0],
            lift:  [postfx.color_lift[0], postfx.color_lift[1], postfx.color_lift[2], 0.0],
            gain:  [postfx.color_gain[0], postfx.color_gain[1], postfx.color_gain[2], 0.0],
            gamma: [postfx.color_gamma[0], postfx.color_gamma[1], postfx.color_gamma[2], 0.0],
        };
        self.queue.write_buffer(&self.tonemap_uniform, 0, bytemuck::bytes_of(&tonemap_params));

        let skybox_params = SkyboxParams {
            values: [1.0, postfx.fog_density, postfx.fog_height_base, postfx.fog_height_falloff],
            fog_color: [postfx.fog_color[0], postfx.fog_color[1], postfx.fog_color[2], 0.0],
        };
        self.queue.write_buffer(&self.skybox_uniform, 0, bytemuck::bytes_of(&skybox_params));

        let noise_tile_x = w_px / 4.0;
        let noise_tile_y = h_px / 4.0;
        let ssao_data = SsaoUniform {
            proj_scale: [proj_unjittered.x_axis.x, proj_unjittered.y_axis.y, camera.far, postfx.ssao_radius],
            params: [0.025, postfx.ssao_strength, noise_tile_x, noise_tile_y],
            time: [time, 0.0, 0.0, 0.0],
            view: view.to_cols_array_2d(),
        };
        self.queue.write_buffer(&self.ssao_uniform, 0, bytemuck::bytes_of(&ssao_data));

        let fog_far = camera.far.min(200.0);
        let vol_data = VolumetricParams {
            grid: [VOLUMETRIC_GRID_W as f32, VOLUMETRIC_GRID_H as f32, 1.0 / VOLUMETRIC_GRID_W as f32, 1.0 / VOLUMETRIC_GRID_H as f32],
            cam: [camera.near, fog_far, (camera.fov_y * 0.5).tan(), camera.aspect],
            params: [postfx.volumetric_density, postfx.volumetric_scattering, postfx.volumetric_phase_g, 0.0],
            fog_color: [postfx.fog_color[0], postfx.fog_color[1], postfx.fog_color[2], 0.0],
        };
        self.queue.write_buffer(&self.volumetric_uniform, 0, bytemuck::bytes_of(&vol_data));

        let debug_params = DebugParams { mode: [postfx.debug_view as u32, 0, 0, 0] };
        self.queue.write_buffer(&self.sd.debug_uniform, 0, bytemuck::bytes_of(&debug_params));

        let (sun_screen, sun_color_arr, sun_visibility) = {
            let view_proj = camera.view_projection();
            if let Some(sun) = dir_lights.first() {
                let sun_dir_world = Vec3::new(sun.direction[0], sun.direction[1], sun.direction[2]).normalize_or_zero();
                let sun_world = camera.position() + sun_dir_world * 1000.0;
                let clip = view_proj * sun_world.extend(1.0);
                if clip.w > 1e-4 {
                    let ndc = clip.truncate() / clip.w;
                    let u = ndc.x * 0.5 + 0.5;
                    let v = 1.0 - (ndc.y * 0.5 + 0.5);
                    let in_x = (0.0..=1.0).contains(&u);
                    let in_y = (0.0..=1.0).contains(&v);
                    let in_front = ndc.z > 0.0 && ndc.z < 1.0;
                    let vis = if in_x && in_y && in_front { 1.0 } else { 0.0 };
                    let rgb = [sun.color[0], sun.color[1], sun.color[2]];
                    ([u, v, 0.0, 0.0], rgb, vis)
                } else {
                    ([0.5, 0.5, 0.0, 0.0], [1.0, 1.0, 1.0], 0.0)
                }
            } else {
                ([0.5, 0.5, 0.0, 0.0], [1.0, 1.0, 1.0], 0.0)
            }
        };

        let lens_flare_params = LensFlareParams {
            sun_screen,
            sun_color: [sun_color_arr[0], sun_color_arr[1], sun_color_arr[2], sun_visibility],
            params: [
                postfx.lens_flare_intensity, postfx.lens_flare_threshold,
                postfx.lens_flare_ghosts as f32, postfx.lens_flare_streak,
            ],
        };
        self.queue.write_buffer(&self.lens_flare_uniform, 0, bytemuck::bytes_of(&lens_flare_params));

        let mut dof_params = DofParams {
            params: [postfx.dof_focus_distance, postfx.dof_focus_range, postfx.dof_max_blur, postfx.dof_blur_falloff],
            screen: [1.0 / w_px, 1.0 / h_px, 0.0, 0.0],
            depth: [camera.near, camera.far, 0.0, 0.0],
        };
        if postfx.dof_enabled < 0.5 { dof_params.params[2] = 0.0; }
        self.queue.write_buffer(&self.dof_uniform, 0, bytemuck::bytes_of(&dof_params));

        let mb_samples = postfx.motion_blur_samples.clamp(2, 32);
        let mb_intensity = if postfx.motion_blur_enabled > 0.5 { postfx.motion_blur_intensity } else { 0.0 };
        let motion_blur_params = MotionBlurParams {
            params: [mb_intensity, postfx.motion_blur_max_px, mb_samples as f32, 0.0],
            screen: [w_px, h_px, 0.0, 0.0],
        };
        self.queue.write_buffer(&self.motion_blur_uniform, 0, bytemuck::bytes_of(&motion_blur_params));

        let fxaa_params = FxaaParams {
            values: [
                1.0 / surface_w, 1.0 / surface_h,
                postfx.fxaa_strength * (1.0 - 0.5 * postfx.taa_strength),
                0.0,
            ],
        };
        self.queue.write_buffer(&self.sd.fxaa_uniform, 0, bytemuck::bytes_of(&fxaa_params));

        let sorted_draws = sort_draws_for_render(draws, camera.position());
        self.last_draw_count = sorted_draws.len();
        self.last_instance_count = sorted_draws.iter().map(|d| d.instances.len()).sum();

        let total_instances: u64 = sorted_draws.iter().map(|d| d.instances.len() as u64).sum();
        if total_instances > 0 {
            self.ensure_instance_capacity(total_instances);
            let stride = std::mem::size_of::<InstanceData>() as u64;
            let mut offset_bytes: u64 = 0;
            for d in &sorted_draws {
                if d.instances.is_empty() { continue; }
                self.queue.write_buffer(&self.instance_buffer, offset_bytes, bytemuck::cast_slice(&d.instances));
                offset_bytes += d.instances.len() as u64 * stride;
            }
        }

        let total_decals: u64 = decals.iter().map(|d| d.instances.len() as u64).sum();
        if total_decals > 0 {
            self.ensure_decal_capacity(total_decals);
            let stride = std::mem::size_of::<DecalInstance>() as u64;
            let mut offset: u64 = 0;
            for d in decals {
                if d.instances.is_empty() { continue; }
                self.queue.write_buffer(&self.decal_instance_buffer, offset, bytemuck::cast_slice(&d.instances));
                offset += d.instances.len() as u64 * stride;
            }
        }

        self.line_buffer.upload(&self.device, &self.queue, line_vertices);

        if !particle_instances.is_empty() {
            self.ensure_particles_capacity(particle_instances.len() as u64);
            self.queue.write_buffer(&self.particles_instance_buffer, 0, bytemuck::cast_slice(particle_instances));
        }

        let frame = match self.surface.get_current_texture() {
            wgpu::CurrentSurfaceTexture::Success(t)
            | wgpu::CurrentSurfaceTexture::Suboptimal(t) => t,
            _ => { self.surface.configure(&self.device, &self.config); return Ok(()); }
        };

        let swap_view = frame.texture.create_view(&wgpu::TextureViewDescriptor::default());
        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor { label: Some("encoder") });

        if postfx.contact_shadow_strength > 0.001 {
            let sun_view = (view * dir_light_dir.extend(0.0))
                .truncate()
                .normalize_or_zero();
            let cs_params = ContactShadowParams {
                params: [
                    postfx.contact_shadow_length,
                    postfx.contact_shadow_thickness,
                    postfx.contact_shadow_strength,
                    0.0,
                ],
                sun_view_dir: [sun_view.x, sun_view.y, sun_view.z, 0.0],
            };
            self.queue.write_buffer(
                &self.contact_shadow_uniform,
                0,
                bytemuck::bytes_of(&cs_params),
            );
        }

        let gpu_dt = (time - self.last_render_time).max(0.0).min(0.1);
        self.last_render_time = time;
        {
            let queue_clone = self.queue.clone();
            self.gpu_particles
                .dispatch(&queue_clone, &mut encoder, gpu_dt, time);
        }

        encoder.clear_buffer(&self.sd.cluster_counts_buffer, 0, None);
        if clustered_light_count > 0 {
            passes::encode_cluster_assign(self, &mut encoder, clustered_light_count as u32);
        }

        passes::encode_csm_all(self, &mut encoder, &sorted_draws);
        if shadow_point_count > 0 {
            passes::encode_cube_shadow_all(self, &mut encoder, &sorted_draws, shadow_point_count as u32);
        }
        passes::encode_gbuffer_pass(self, &mut encoder, &sorted_draws);

        if postfx.contact_shadow_strength > 0.001 {
            passes::encode_contact_shadow_pass(self, &mut encoder);
        }

        passes::encode_decal_pass(self, &mut encoder, decals);
        passes::encode_ssao_pass(self, &mut encoder);
        passes::encode_ssao_blur_pass(self, &mut encoder);
        passes::encode_lighting_pass(self, &mut encoder);

        if self.atmosphere_settings.enabled {
            let cam_h = camera.position().y.max(1.0).min(5000.0);
            let mut atmo_params =
                AtmosphereParams::from_settings(&self.atmosphere_settings, cam_h);
            if dir_light_dir.length_squared() > 1e-6 {
                let n = dir_light_dir.normalize();
                atmo_params.sun[0] = n.x;
                atmo_params.sun[1] = n.y;
                atmo_params.sun[2] = n.z;
            }
            self.queue.write_buffer(&self.atmosphere_uniform, 0, bytemuck::bytes_of(&atmo_params));
            passes::encode_atmosphere_pass(self, &mut encoder);
        } else {
            passes::encode_skybox_pass(self, &mut encoder);
        }

        passes::encode_forward_pass(self, &mut encoder, line_vertices);
        passes::encode_particles_pass(self, &mut encoder, particle_instances.len() as u32);
        passes::encode_gpu_particles_pass(self, &mut encoder);
        passes::encode_transparent_pass(self, &mut encoder, &sorted_draws);
        passes::encode_volumetric_compute(self, &mut encoder);
        passes::encode_volumetric_composite(self, &mut encoder);

        if postfx.lens_flare_intensity > 0.001 && sun_visibility > 0.5 {
            passes::encode_lens_flare_pass(self, &mut encoder);
        }

        passes::encode_dof_pass(self, &mut encoder);
        passes::encode_motion_blur_pass(self, &mut encoder);

        if use_taa {
            passes::encode_taa_pass(self, &mut encoder, write_idx);
        }

        if postfx.debug_view.is_debug() {
            passes::encode_debug_pass(self, &mut encoder, &swap_view, postfx.debug_view);
        } else {
            passes::encode_post_processing(self, &mut encoder, &swap_view, write_idx, use_taa);
        }

        if !ui_quads.is_empty() {
            let ui_global = UiGlobal {
                screen: [
                    self.config.width as f32, self.config.height as f32,
                    2.0 / self.config.width.max(1) as f32, 2.0 / self.config.height.max(1) as f32,
                ],
                time: [time, 0.0, 0.0, 0.0],
            };
            self.queue.write_buffer(&self.ui_global_buffer, 0, bytemuck::bytes_of(&ui_global));
            self.ensure_ui_capacity(ui_quads.len() as u64);
            self.queue.write_buffer(&self.ui_instance_buffer, 0, bytemuck::cast_slice(ui_quads));
            passes::encode_ui_pass(self, &mut encoder, &swap_view, ui_quads.len() as u32);
        }

        if let Some(egui_data) = egui_data {
            let screen_descriptor = egui_wgpu::ScreenDescriptor {
                size_in_pixels: [self.config.width, self.config.height],
                pixels_per_point: egui_data.pixels_per_point,
            };
            let user_cmd_bufs = egui_data.renderer.update_buffers(
                &self.device, &self.queue, &mut encoder,
                &egui_data.clipped_primitives, &screen_descriptor,
            );
            self.queue.submit(user_cmd_bufs);
            {
                let mut pass = encoder
                    .begin_render_pass(&wgpu::RenderPassDescriptor {
                        label: Some("egui_pass"),
                        color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                            view: &swap_view, resolve_target: None,
                            ops: wgpu::Operations { load: wgpu::LoadOp::Load, store: wgpu::StoreOp::Store },
                            depth_slice: None,
                        })],
                        depth_stencil_attachment: None,
                        timestamp_writes: None, occlusion_query_set: None, multiview_mask: None,
                    })
                    .forget_lifetime();
                egui_data.renderer.render(&mut pass, &egui_data.clipped_primitives, &screen_descriptor);
            }
        }

        self.queue.submit(Some(encoder.finish()));
        self.queue.present(frame);
        Ok(())
    }
}

#[cfg(debug_assertions)]
struct BuiltPipelines {
    gbuffer: wgpu::RenderPipeline,
    gbuffer_double_sided: wgpu::RenderPipeline,
    shadow: wgpu::RenderPipeline,
    shadow_double_sided: wgpu::RenderPipeline,
    line: wgpu::RenderPipeline,
    particles: wgpu::RenderPipeline,
    transparent: wgpu::RenderPipeline,
    transparent_double_sided: wgpu::RenderPipeline,
    lighting: wgpu::RenderPipeline,
    ssao: (wgpu::RenderPipeline, wgpu::RenderPipeline),
    bloom_chain: (wgpu::RenderPipeline, wgpu::RenderPipeline, wgpu::RenderPipeline),
    tonemap: wgpu::RenderPipeline,
    debug: (wgpu::RenderPipeline, wgpu::RenderPipeline),
    fxaa: wgpu::RenderPipeline,
    skybox: wgpu::RenderPipeline,
    atmosphere: wgpu::RenderPipeline,
    taa: wgpu::RenderPipeline,
    decal: wgpu::RenderPipeline,
    lens_flare: wgpu::RenderPipeline,
    dof: wgpu::RenderPipeline,
    motion_blur: wgpu::RenderPipeline,
    volumetric_composite: wgpu::RenderPipeline,
}

fn bgl_tex_frag(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding, visibility: wgpu::ShaderStages::FRAGMENT,
        ty: wgpu::BindingType::Texture {
            sample_type: wgpu::TextureSampleType::Float { filterable: true },
            view_dimension: wgpu::TextureViewDimension::D2,
            multisampled: false,
        }, count: None,
    }
}

fn bgl_tex3d_frag(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding, visibility: wgpu::ShaderStages::FRAGMENT,
        ty: wgpu::BindingType::Texture {
            sample_type: wgpu::TextureSampleType::Float { filterable: true },
            view_dimension: wgpu::TextureViewDimension::D3,
            multisampled: false,
        }, count: None,
    }
}

fn bgl_cube_frag(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding, visibility: wgpu::ShaderStages::FRAGMENT,
        ty: wgpu::BindingType::Texture {
            sample_type: wgpu::TextureSampleType::Float { filterable: true },
            view_dimension: wgpu::TextureViewDimension::Cube,
            multisampled: false,
        }, count: None,
    }
}

fn bgl_depth_2d(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding, visibility: wgpu::ShaderStages::FRAGMENT,
        ty: wgpu::BindingType::Texture {
            sample_type: wgpu::TextureSampleType::Depth,
            view_dimension: wgpu::TextureViewDimension::D2,
            multisampled: false,
        }, count: None,
    }
}

fn bgl_depth_2darray(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding, visibility: wgpu::ShaderStages::FRAGMENT,
        ty: wgpu::BindingType::Texture {
            sample_type: wgpu::TextureSampleType::Depth,
            view_dimension: wgpu::TextureViewDimension::D2Array,
            multisampled: false,
        }, count: None,
    }
}

fn bgl_depth_cubearray(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding, visibility: wgpu::ShaderStages::FRAGMENT,
        ty: wgpu::BindingType::Texture {
            sample_type: wgpu::TextureSampleType::Depth,
            view_dimension: wgpu::TextureViewDimension::CubeArray,
            multisampled: false,
        }, count: None,
    }
}

fn bgl_sampler_frag(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding, visibility: wgpu::ShaderStages::FRAGMENT,
        ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
        count: None,
    }
}

fn bgl_sampler_nonfiltering_frag(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding,
        visibility: wgpu::ShaderStages::FRAGMENT,
        ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::NonFiltering),
        count: None,
    }
}

fn bgl_cmp_sampler(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding, visibility: wgpu::ShaderStages::FRAGMENT,
        ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Comparison),
        count: None,
    }
}

fn bgl_cmp_sampler_compute(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding, visibility: wgpu::ShaderStages::COMPUTE,
        ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Comparison),
        count: None,
    }
}

fn bgl_uniform_frag(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding, visibility: wgpu::ShaderStages::FRAGMENT,
        ty: wgpu::BindingType::Buffer {
            ty: wgpu::BufferBindingType::Uniform,
            has_dynamic_offset: false,
            min_binding_size: None,
        }, count: None,
    }
}

fn bgl_uniform_compute(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding, visibility: wgpu::ShaderStages::COMPUTE,
        ty: wgpu::BindingType::Buffer {
            ty: wgpu::BufferBindingType::Uniform,
            has_dynamic_offset: false,
            min_binding_size: None,
        }, count: None,
    }
}

fn make_gbuffer_pipeline(device: &wgpu::Device, camera_layout: &wgpu::BindGroupLayout, material_layout: &wgpu::BindGroupLayout, cull: Option<wgpu::Face>) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/shaders/gbuffer.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("gbuffer_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("gbuffer_pipeline_layout"),
        bind_group_layouts: &[Some(camera_layout), Some(material_layout)],
        immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("gbuffer_pipeline"),
        layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[Some(Vertex3D::layout()), Some(InstanceData::layout())], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[
                Some(wgpu::ColorTargetState { format: GBUFFER_FORMAT, blend: None, write_mask: wgpu::ColorWrites::ALL }),
                Some(wgpu::ColorTargetState { format: GBUFFER_FORMAT, blend: None, write_mask: wgpu::ColorWrites::ALL }),
                Some(wgpu::ColorTargetState { format: GBUFFER_FORMAT, blend: None, write_mask: wgpu::ColorWrites::ALL }),
                Some(wgpu::ColorTargetState { format: MOTION_FORMAT, blend: None, write_mask: wgpu::ColorWrites::ALL }),
            ],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, front_face: wgpu::FrontFace::Ccw, cull_mode: cull, ..Default::default() },
        depth_stencil: Some(wgpu::DepthStencilState {
            format: DEPTH_FORMAT, depth_write_enabled: Some(true), depth_compare: Some(wgpu::CompareFunction::Less),
            stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_shadow_pipeline(device: &wgpu::Device, shadow_pass_layout: &wgpu::BindGroupLayout, material_layout: &wgpu::BindGroupLayout, cull: Option<wgpu::Face>) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/shadow.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("shadow_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("shadow_pipeline_layout"),
        bind_group_layouts: &[Some(shadow_pass_layout), Some(material_layout)],
        immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("shadow_pipeline"),
        layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[Some(Vertex3D::layout()), Some(InstanceData::layout())], compilation_options: Default::default() },
        fragment: None,
        primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, front_face: wgpu::FrontFace::Ccw, cull_mode: cull, ..Default::default() },
        depth_stencil: Some(wgpu::DepthStencilState {
            format: DEPTH_FORMAT, depth_write_enabled: Some(true), depth_compare: Some(wgpu::CompareFunction::Less),
            stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState { constant: 4, slope_scale: 2.0, clamp: 0.0 },
        }),
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_line_pipeline(device: &wgpu::Device, camera_layout: &wgpu::BindGroupLayout) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/shaders/lines.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("line_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("line_pipeline_layout"), bind_group_layouts: &[Some(camera_layout)], immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("line_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[Some(LineVertex::layout())], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState { format: HDR_FORMAT, blend: Some(wgpu::BlendState::ALPHA_BLENDING), write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::LineList, front_face: wgpu::FrontFace::Ccw, ..Default::default() },
        depth_stencil: Some(wgpu::DepthStencilState {
            format: DEPTH_FORMAT, depth_write_enabled: Some(true), depth_compare: Some(wgpu::CompareFunction::Less),
            stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_particles_pipeline(device: &wgpu::Device, camera_layout: &wgpu::BindGroupLayout) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/particles.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("particles_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("particles_pipeline_layout"), bind_group_layouts: &[Some(camera_layout)], immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("particles_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[Some(ParticleInstance::layout())], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState { format: HDR_FORMAT, blend: Some(wgpu::BlendState::ALPHA_BLENDING), write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, front_face: wgpu::FrontFace::Ccw, cull_mode: None, ..Default::default() },
        depth_stencil: Some(wgpu::DepthStencilState {
            format: DEPTH_FORMAT, depth_write_enabled: Some(false), depth_compare: Some(wgpu::CompareFunction::Less),
            stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_transparent_pipeline(device: &wgpu::Device, camera_layout: &wgpu::BindGroupLayout, lights_layout: &wgpu::BindGroupLayout, shadow2_layout: &wgpu::BindGroupLayout, material_layout: &wgpu::BindGroupLayout, cull: Option<wgpu::Face>) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/shaders/forward_transparent.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("transparent_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("transparent_pipeline_layout"),
        bind_group_layouts: &[Some(camera_layout), Some(lights_layout), Some(shadow2_layout), Some(material_layout)],
        immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("transparent_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[Some(Vertex3D::layout()), Some(InstanceData::layout())], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[
                Some(wgpu::ColorTargetState { format: HDR_FORMAT, blend: Some(wgpu::BlendState::ALPHA_BLENDING), write_mask: wgpu::ColorWrites::ALL }),
                Some(wgpu::ColorTargetState { format: MOTION_FORMAT, blend: Some(wgpu::BlendState::REPLACE), write_mask: wgpu::ColorWrites::ALL }),
            ],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, front_face: wgpu::FrontFace::Ccw, cull_mode: cull, ..Default::default() },
        depth_stencil: Some(wgpu::DepthStencilState {
            format: DEPTH_FORMAT, depth_write_enabled: Some(false), depth_compare: Some(wgpu::CompareFunction::Less),
            stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

/// FIX: 5 bind-group-layout'ов вместо 4.
///
/// Ранее `probe_lighting_layout` приходил как `_probe_lighting_layout`
/// и не включался в pipeline layout. `deferred_lighting.wgsl` объявляет
/// @group(4) для reflection probes — это ломало либо создание pipeline
/// (validation error), либо probes не работали (bind group missing).
fn make_lighting_pipeline(
    device: &wgpu::Device,
    lighting_layout: &wgpu::BindGroupLayout,
    lights_layout: &wgpu::BindGroupLayout,
    shadow2_layout: &wgpu::BindGroupLayout,
    cluster_lighting_layout: &wgpu::BindGroupLayout,
    probe_lighting_layout: &wgpu::BindGroupLayout,
) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/shaders/deferred_lighting.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("lighting_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("lighting_pipeline_layout"),
        bind_group_layouts: &[
            Some(lighting_layout),
            Some(lights_layout),
            Some(shadow2_layout),
            Some(cluster_lighting_layout),
            Some(probe_lighting_layout),
        ],
        immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("lighting_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState { format: HDR_FORMAT, blend: None, write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_ssao_pipelines(device: &wgpu::Device, ssao_layout: &wgpu::BindGroupLayout) -> Result<(wgpu::RenderPipeline, wgpu::RenderPipeline), String> {
    let src = crate::shader_source!("src/render/shaders/ssao.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("ssao_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("ssao_pipeline_layout"), bind_group_layouts: &[Some(ssao_layout)], immediate_size: 0,
    });
    let main = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("ssao_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_ssao"),
            targets: &[Some(wgpu::ColorTargetState { format: SSAO_FORMAT, blend: None, write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    });
    let blur = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("ssao_blur_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_blur"),
            targets: &[Some(wgpu::ColorTargetState { format: SSAO_FORMAT, blend: None, write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    });
    Ok((main, blur))
}

fn make_bloom_chain_pipelines(device: &wgpu::Device, bloom_layout: &wgpu::BindGroupLayout) -> Result<(wgpu::RenderPipeline, wgpu::RenderPipeline, wgpu::RenderPipeline), String> {
    let src = crate::shader_source!("src/render/bloom.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("bloom_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("bloom_pipeline_layout"), bind_group_layouts: &[Some(bloom_layout)], immediate_size: 0,
    });
    let make = |entry: &str, blend: Option<wgpu::BlendState>| {
        device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some(entry), layout: Some(&layout),
            vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
            fragment: Some(wgpu::FragmentState {
                module: &shader, entry_point: Some(entry),
                targets: &[Some(wgpu::ColorTargetState { format: HDR_FORMAT, blend, write_mask: wgpu::ColorWrites::ALL })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
            multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
        })
    };
    let prefilter = make("fs_prefilter", None);
    let downsample = make("fs_downsample", None);
    let upsample_blend = wgpu::BlendState {
        color: wgpu::BlendComponent { src_factor: wgpu::BlendFactor::One, dst_factor: wgpu::BlendFactor::One, operation: wgpu::BlendOperation::Add },
        alpha: wgpu::BlendComponent::OVER,
    };
    let upsample = make("fs_upsample", Some(upsample_blend));
    Ok((prefilter, downsample, upsample))
}

fn make_tonemap_pipeline(device: &wgpu::Device, _config: &wgpu::SurfaceConfiguration, tonemap_layout: &wgpu::BindGroupLayout) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/tonemap.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("tonemap_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("tonemap_pipeline_layout"), bind_group_layouts: &[Some(tonemap_layout)], immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("tonemap_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState { format: LDR_FORMAT, blend: Some(wgpu::BlendState::REPLACE), write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_fxaa_pipeline(device: &wgpu::Device, config: &wgpu::SurfaceConfiguration, fxaa_layout: &wgpu::BindGroupLayout) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/fxaa.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("fxaa_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("fxaa_pipeline_layout"), bind_group_layouts: &[Some(fxaa_layout)], immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("fxaa_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState { format: config.format, blend: Some(wgpu::BlendState::REPLACE), write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_skybox_pipeline(device: &wgpu::Device, skybox_layout: &wgpu::BindGroupLayout) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/shaders/skybox.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("skybox_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("skybox_pipeline_layout"), bind_group_layouts: &[Some(skybox_layout)], immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("skybox_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState { format: HDR_FORMAT, blend: None, write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: Some(wgpu::DepthStencilState {
            format: DEPTH_FORMAT, depth_write_enabled: Some(false), depth_compare: Some(wgpu::CompareFunction::LessEqual),
            stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_taa_pipeline(device: &wgpu::Device, taa_layout: &wgpu::BindGroupLayout) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/shaders/taa.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("taa_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("taa_pipeline_layout"), bind_group_layouts: &[Some(taa_layout)], immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("taa_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState { format: HDR_FORMAT, blend: None, write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_decal_pipeline(device: &wgpu::Device, camera_layout: &wgpu::BindGroupLayout, decal_texture_layout: &wgpu::BindGroupLayout, decal_depth_layout: &wgpu::BindGroupLayout) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/shaders/decal.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("decal_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("decal_pipeline_layout"),
        bind_group_layouts: &[Some(camera_layout), Some(decal_texture_layout), Some(decal_depth_layout)],
        immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("decal_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[Some(Vertex3D::layout()), Some(DecalInstance::layout())], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[
                Some(wgpu::ColorTargetState {
                    format: GBUFFER_FORMAT,
                    blend: Some(wgpu::BlendState {
                        color: wgpu::BlendComponent { src_factor: wgpu::BlendFactor::SrcAlpha, dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha, operation: wgpu::BlendOperation::Add },
                        alpha: wgpu::BlendComponent { src_factor: wgpu::BlendFactor::Zero, dst_factor: wgpu::BlendFactor::One, operation: wgpu::BlendOperation::Add },
                    }),
                    write_mask: wgpu::ColorWrites::ALL,
                }),
                Some(wgpu::ColorTargetState { format: GBUFFER_FORMAT, blend: None, write_mask: wgpu::ColorWrites::empty() }),
                Some(wgpu::ColorTargetState { format: GBUFFER_FORMAT, blend: None, write_mask: wgpu::ColorWrites::empty() }),
                Some(wgpu::ColorTargetState { format: MOTION_FORMAT, blend: None, write_mask: wgpu::ColorWrites::empty() }),
            ],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, front_face: wgpu::FrontFace::Ccw, cull_mode: None, ..Default::default() },
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_debug_pipelines(device: &wgpu::Device, config: &wgpu::SurfaceConfiguration, debug_layout: &wgpu::BindGroupLayout, debug_depth_layout: &wgpu::BindGroupLayout) -> Result<(wgpu::RenderPipeline, wgpu::RenderPipeline), String> {
    let src2d = crate::shader_source!("src/render/shaders/debug2d.wgsl")?;
    let src_depth = crate::shader_source!("src/render/shaders/debug_depth.wgsl")?;
    let shader2d = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("debug2d_shader"), source: wgpu::ShaderSource::Wgsl(src2d.into()) });
    let shader_depth = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("debug_depth_shader"), source: wgpu::ShaderSource::Wgsl(src_depth.into()) });
    let layout2d = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("debug2d_layout"), bind_group_layouts: &[Some(debug_layout)], immediate_size: 0,
    });
    let layout_depth = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("debug_depth_layout"), bind_group_layouts: &[Some(debug_depth_layout)], immediate_size: 0,
    });
    let pipeline2d = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("debug2d_pipeline"), layout: Some(&layout2d),
        vertex: wgpu::VertexState { module: &shader2d, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader2d, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState { format: config.format, blend: Some(wgpu::BlendState::REPLACE), write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    });
    let pipeline_depth = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("debug_depth_pipeline"), layout: Some(&layout_depth),
        vertex: wgpu::VertexState { module: &shader_depth, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader_depth, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState { format: config.format, blend: Some(wgpu::BlendState::REPLACE), write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    });
    Ok((pipeline2d, pipeline_depth))
}

fn make_lens_flare_pipeline(device: &wgpu::Device, lens_flare_layout: &wgpu::BindGroupLayout, target_format: wgpu::TextureFormat) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/shaders/lens_flare.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("lens_flare_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("lens_flare_pipeline_layout"), bind_group_layouts: &[Some(lens_flare_layout)], immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("lens_flare_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format: target_format,
                blend: Some(wgpu::BlendState {
                    color: wgpu::BlendComponent { src_factor: wgpu::BlendFactor::One, dst_factor: wgpu::BlendFactor::One, operation: wgpu::BlendOperation::Add },
                    alpha: wgpu::BlendComponent::OVER,
                }),
                write_mask: wgpu::ColorWrites::ALL,
            })], compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_dof_pipeline(device: &wgpu::Device, dof_layout: &wgpu::BindGroupLayout, target_format: wgpu::TextureFormat) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/shaders/dof.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("dof_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("dof_pipeline_layout"), bind_group_layouts: &[Some(dof_layout)], immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("dof_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState { format: target_format, blend: Some(wgpu::BlendState::REPLACE), write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}

fn make_motion_blur_pipeline(device: &wgpu::Device, motion_blur_layout: &wgpu::BindGroupLayout, target_format: wgpu::TextureFormat) -> Result<wgpu::RenderPipeline, String> {
    let src = crate::shader_source!("src/render/shaders/motion_blur.wgsl")?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("motion_blur_shader"), source: wgpu::ShaderSource::Wgsl(src.into()) });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("motion_blur_pipeline_layout"), bind_group_layouts: &[Some(motion_blur_layout)], immediate_size: 0,
    });
    Ok(device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("motion_blur_pipeline"), layout: Some(&layout),
        vertex: wgpu::VertexState { module: &shader, entry_point: Some("vs_main"), buffers: &[], compilation_options: Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: &shader, entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState { format: target_format, blend: Some(wgpu::BlendState::REPLACE), write_mask: wgpu::ColorWrites::ALL })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(), depth_stencil: None,
        multisample: wgpu::MultisampleState::default(), multiview_mask: None, cache: None,
    }))
}